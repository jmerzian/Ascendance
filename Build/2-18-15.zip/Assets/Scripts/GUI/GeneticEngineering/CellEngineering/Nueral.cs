using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public static partial class CellEngineering
{
	private static bool[] nueronEdit = new bool[]{false,false};
	public static string[] nueronType = new string[]{"Sensor","Processor"};

	private static void NueralDisplay()
	{
		/*********************************************
		 * Left Collumn
		 * ******************************************/
		GUI.BeginGroup (new Rect (20, 40, 300, Screen.height));
		//name of cell
		name = GUI.TextField(new Rect(0,0,300,20),name);
		//height of section
		float sectionHeight = (Screen.height-240) / 4;
		
		int i = 0;

		if(nueronEdit[0])
		{
			GUI.Label (new Rect (0,40,240,24), "Energy Sources");
			scroll[3] = GUI.BeginScrollView (new Rect(0,64,260,sectionHeight), scroll[3], new Rect(0, 0, 240,Control.energies.Count*40));
			i = 0;
			foreach(string energy in Control.energies)
			{
				GUI.Label(new Rect(0,40*i,80,40),Control.energies[i]);
				tempCell.energyIn[energy] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),tempCell.energyIn[energy],0,1);
				i++;
			}
			GUI.EndScrollView();
			
			GUI.Label (new Rect (0,80+sectionHeight,240,24), "Organic Sources");
			scroll[2] = GUI.BeginScrollView (new Rect(0,104+sectionHeight,260,sectionHeight), scroll[2], new Rect(0, 0, 240,Control.organics.Count*40));
			i = 0;
			foreach(string organic in Control.organics)
			{
				GUI.Label(new Rect(0,40*i,80,40),Control.organics[i]);
				tempCell.resourceIn[organic] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),tempCell.resourceIn[organic],0,1);
				i++;
			}
			GUI.EndScrollView();
			
			GUI.Label (new Rect (0,120+2*sectionHeight,240,24), "Mineral Sources");
			scroll[1] = GUI.BeginScrollView (new Rect(0,144+2*sectionHeight,260,sectionHeight), scroll[1], new Rect(0, 0, 240,Control.minerals.Count*40));
			i = 0;
			foreach(string mineral in Control.minerals)
			{
				GUI.Label(new Rect(0,40*i,80,40),Control.minerals[i]);
				tempCell.resourceIn[mineral] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),tempCell.resourceIn[mineral],0,1);
				i++;
			}
			GUI.EndScrollView ();
			
			GUI.Label (new Rect (0,160+3*sectionHeight,240,24), "Gas Sources");
			scroll[0] = GUI.BeginScrollView (new Rect(0,184+ 3*sectionHeight,260,sectionHeight), scroll[0], new Rect(0, 0, 240,Control.gasses.Count*40));
			i = 0;
			foreach(string gas in Control.gasses)
			{
				GUI.Label(new Rect(0,40*i,80,40),Control.gasses[i]);
				tempCell.resourceIn[gas] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),tempCell.resourceIn[gas],0,1);
				i++;
			}
			GUI.EndScrollView ();
		}
		else if(nueronEdit[1])
		{
		}
		GUI.EndGroup ();

		/************************************************************
		 * Right Collumn
		 * *********************************************************/
		GUI.BeginGroup (new Rect(Screen.width-240,20,240,Screen.height));
		GUI.Label(new Rect(0,0,240,40),"Resources Consumed");
		scroll[4] = GUI.BeginScrollView (new Rect(0,20,240,Screen.height-360), scroll[4], new Rect(0, 0, 220,outputTextRows*20));
		i = 0;
		//TODO display the resources used
		outputTextRows = i;
		GUI.EndScrollView ();
		
		GUI.Label(new Rect(0,360,240,40),"Energy Outputs");
		scroll[5] = GUI.BeginScrollView (new Rect(0,400,240,Screen.height-120), scroll[5], new Rect(0, 0, 220,outputTextRows*40));
		i = 0;
		foreach (KeyValuePair<string, float> energy in tempCell.energyOut)
		{
			GUI.Label(new Rect(0,20*i,200,20),energy.Key + " " + energy.Value.ToString("F2"));
			i++;
		}
		outputTextRows = i;
		GUI.EndScrollView ();
		
		if(GUI.Button(new Rect(0,Screen.height-60,100,30),"Save Cell"))
		{
			//Run checks to make sure that it is a valid Cell
			if(ValidProducer())
			{
				tempCell.name = name;
				savedCells.Add(name,new Cell(tempCell));
				tempCell = new Cell();
				GUIMain.windowDisplay[6] = false;
			}
		}
		if(GUI.Button(new Rect(100,Screen.height-60,100,30),"Close"))
		{
			GUIMain.windowDisplay[6] = false;
		}
		GUI.EndGroup ();
	}

	/********************************************
	 * Check to see if the cell is valid
	 * *************************************/
	private static bool ValidNueral()
	{
			if (savedCells.ContainsKey (name))return false;
			return true;
	}
}