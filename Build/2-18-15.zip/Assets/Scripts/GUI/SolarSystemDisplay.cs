using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public static class SolarSystemDisplay
{
	private static List<Transform> sunOrbits;
	private static Dictionary<Transform,List<Transform>> planetOrbits = new Dictionary<Transform,List<Transform>>();

	public static void SetUp(List<Texture> textures, Transform sun)
	{
		sunOrbits = Control.ChildrenPlanets (sun);
		foreach(Transform planet in sunOrbits)
		{
			planetOrbits.Add(planet,Control.ChildrenPlanets(planet));
		}
	}
	public static void DisplaySystem(List<Texture> textures)
	{
		//Set the skin
		GUI.skin = GUIMain.infoSkin;

		GUI.Box (new Rect (0, Screen.height - 125, 125, 125), textures [0]);

		for(int i = 0; i < sunOrbits.Count; i++)
		{
			if(GUI.Button (new Rect (125 + 64*i, Screen.height - 64,64,64), textures[1]))
	        {
	       		Control.focusObject = sunOrbits[i];
				Control.zoom = 4;
			}
			for(int j = 0; j < planetOrbits[sunOrbits[i]].Count; j++)
			{
				if(GUI.Button (new Rect (125 + 64*i, Screen.height - 96 - 32*j,32,32), textures[2]))
				{
					Control.focusObject = planetOrbits[sunOrbits[i]][j];
					Control.zoom = 4;
				}
			}
		}
	}
}