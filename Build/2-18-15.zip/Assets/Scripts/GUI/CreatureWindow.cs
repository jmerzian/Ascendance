using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public static class CreatureWindow
{
	private static Planet planet;
	private static Biome biome;

	private static Bacteria displayedBacteria;

	private static Vector2[] scroll = new Vector2[10];

	public static void WindowInformation(int ID)
	{
		//Set the skin
		GUI.skin = GUIMain.infoSkin;

		planet = GUIDisplay.printedPlanet;
		biome = GUIDisplay.printedBiome;
		//use ID to switch what list is loaded
		switch(ID)
		{
			//sentient
		case 0:
			break;
			//animal
		case 1:
			break;
			//plant
		case 2:
			break;
			//Bacteria
		case 3:
			if(biome != null)
			{
				if(biome.life.bacteria.Count > 0)
				{
					scroll[0] = GUI.BeginScrollView(new Rect(0,40,240,Screen.height-80), scroll[0], new Rect(0, 0, 240,biome.life.bacteria.Count));
					int i = 0;
					foreach(KeyValuePair<string,Bacteria> bacteria in biome.life.bacteria)
					{
						GUI.DrawTexture(new Rect(0,30*i,30,30),bacteria.Value.sprite, ScaleMode.ScaleToFit);
						if(GUI.Button(new Rect(40,30*i,200,24),bacteria.Key)) displayedBacteria = bacteria.Value;
						i++;
					}
					GUI.EndScrollView();

					displayBacteria();
				}
				else GUI.Label(new Rect(0,40,240,Screen.height-80), "This biome is devoid of life");
			}
			else if(planet != null)
			{
				if(planet.planetLife.Count > 0)
				{
					scroll[0] = GUI.BeginScrollView(new Rect(0,40,240,Screen.height-80), scroll[0], new Rect(0, 0, 240,planet.planetLife.Count ));
					int i = 0;
					foreach(KeyValuePair<int,LifeResources> life in planet.planetLife)
					{
						foreach(KeyValuePair<string,Bacteria> bacteria in life.Value.bacteria)
						{
							GUI.DrawTexture(new Rect(0,30*i,30,30),bacteria.Value.sprite, ScaleMode.ScaleToFit);
							if(GUI.Button(new Rect(40,30*i,200,24),bacteria.Key)) displayedBacteria = bacteria.Value;
							i++;
							//if(GUI.Button(new Rect(40,30*i,200,24),"Go to Biome")) GUIDisplay.printedBiome = planet.GetPlanetBiomes()[life.Key];
							i++;
						}
					}
					GUI.EndScrollView();
					
					displayBacteria();
				}
				else GUI.Label(new Rect(0,40,240,Screen.height-80), "This Planet is devoid of life");
			}
			else
			{
				
			}
			break;
		}
		//allow the window to be resized
		GUI.DragWindow ();
	}

	private static void displayBacteria()
	{
		GUI.BeginGroup (new Rect(240,40,Screen.width - 240, Screen.height - 40));
		//Portrait
		if(displayedBacteria != null)
		{
			GUI.DrawTexture(new Rect(0,0,320,320),displayedBacteria.sprite);
		}
		GUI.EndGroup ();
	}
}