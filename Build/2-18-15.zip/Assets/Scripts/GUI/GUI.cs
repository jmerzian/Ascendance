using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public static class GUIDisplay
{
	//whether or not to display the biome or planet information
	public static bool printBiome;
	public static bool printPlanet;

	//which biome or planet to print
	public static Biome printedBiome;
	public static Planet printedPlanet;
}