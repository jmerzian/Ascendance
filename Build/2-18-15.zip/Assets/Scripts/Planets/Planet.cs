﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Planet : MonoBehaviour
{
	/*********************************************************************************
	 * variables describing the planet
	 * ******************************************************************************/
	public string planetType;

	public float Radius;
	public float Orbit;
	public int startAngle;
	public float OrbitSpeed;

	public bool explored;

	/**************************************************************************
	 * Describing the planet mesh
	 * ************************************************************************/
	private Mesh mesh;
	private Vector3[] Vertice;
	private Vector2[] UV;
	private int[] triangles;

	public Shader shader;
	public Color color;
	public Texture defaultTex;
	private Texture2D UVMap;// = new Texture2D(240,240);

	/***************************************************************************
	 * Values describing the resources and location of said resources
	 * *************************************************************************/
	public PlanetResources resources;
	//make resources addable from the main unity window
	public float[] newResources;

	//Information about biome elevations 5 per biome
	public int numOfElevations;
	public int[] elevation;
	public int elevationRange;

	//Information about liquid levels
	public int seaLevel;

	/*****************************************************************************
	 * Hold information about the biomes and creatures living on them
	 * **************************************************************************/
	//Dictionary holding vertice values which point to an int...
	public Dictionary<Vector3,int> vectorMap = new Dictionary<Vector3,int>();

	//that int points to a biome...
	public Dictionary<int,Biome> planetBiomes = new Dictionary<int,Biome>();
	public Dictionary<int,LifeResources> planetLife = new Dictionary<int,LifeResources>();

	//...and to a UV coordinate
	private Dictionary<int,Vector2> biomeMap = new Dictionary<int, Vector2> ();

	//interactivity functions
	private bool hasBeenRevealed = false;

	/***********************************************************
	 * Initialize planet to be at x position, and set up biomes
	 * *********************************************************/
	public void Init() 
	{
		/****************************************
		 * Create the mesh
		 * ************************************/
		Mesh newMesh = new Mesh ();
		Vertice = new Vector3[numOfElevations * 3];
		UV = new Vector2[numOfElevations * 3];
		triangles = new int[numOfElevations * 6];

		elevation = new int[numOfElevations];
		int numOfBiomes = numOfElevations / 5;

		//Create the vertice locations
		for (int i = 0; i < numOfElevations; i++)
		{
			//set each of the starting elevations to a random value
			elevation[i] = Random.Range(-elevationRange,elevationRange);
			float angle = i*2*Mathf.PI/numOfElevations;
			for(int j = 0; j < 3; j++)
			{
				//set vector position
				float radius = Radius - j*Radius/10 + elevation[i]*Radius/50;
				Vertice[j*numOfElevations + i] = new Vector3((radius)*Mathf.Cos(angle),(radius)*Mathf.Sin(angle),j*Radius/10);

				//add vector to map mapping it's coordinates to a biome so long as it isn't an edge
				int biomeNum = ((int)(5*((float)i/(float)numOfElevations)));
				if(i%5 != 0)vectorMap.Add(Vertice[j*numOfElevations + i],biomeNum);
				Debug.Log("Biome number" + biomeNum + " of " + numOfBiomes);
			}
		}

		//TODO if this works fix it so that it works with the last part... because that is currently a little bit wierd...

		for(int i = 0; i < numOfElevations; i++)
		{
			for(int j = 0 ; j < 1; j++)
			{
				//SET THE TRIANGLES
				//triangle 1
				triangles[6*i+j*numOfElevations] = i + j*numOfElevations; 
				triangles[6*i+1+j*numOfElevations] = i+1+j*numOfElevations; 
				triangles[6*i+2+j*numOfElevations] = i+numOfElevations+j*numOfElevations; 
				//triangle two
				if((i+1) != numOfElevations)
				{
					triangles[6*i+5+j*numOfElevations] = i+1+j*numOfElevations; 
					triangles[6*i+4+j*numOfElevations] = i+numOfElevations+j*numOfElevations; 
					triangles[6*i+3+j*numOfElevations] = i+1+numOfElevations+j*numOfElevations;
				}
				else
				{
					triangles[6*i+3+j*numOfElevations] = i+j*numOfElevations; 
					triangles[6*i+4+j*numOfElevations] = i + 1 - numOfElevations+j*numOfElevations; 
					triangles[6*i+5+j*numOfElevations] = i + 1 +j*numOfElevations;
				}

				//SET THE UV MAP
				UV[j*i + i] = new Vector2((float)(2*i)/(float)numOfElevations,j);
				Debug.Log("UV " + (j*i + i).ToString() + " mapped to " + UV[j*i + i]);
			}
		}

		//assign the mesh the new values
		newMesh.vertices = Vertice;
		newMesh.triangles = triangles;
		newMesh.RecalculateNormals ();

		//Change the object's position
		transform.position = new Vector3 (transform.parent.position.x+Orbit*Mathf.Cos(startAngle), transform.parent.position.y+Orbit*Mathf.Sin(startAngle), 0);
	
		/************************************************************************
		 * Add biomes, resources and textures
		 * *********************************************************************/
		resources = new PlanetResources(newResources);

		//Create the biomes
		for(int i = 0; i < numOfBiomes; i++)
		{
			if(planetType == "Active") planetBiomes.Add(i,new Biome("Lava"));
		}

		//Set the textures
		UVMap = new Texture2D (numOfElevations * 120, 480);
		Texture2D[,] UVTextures = new Texture2D[numOfElevations, 2];

		for(int x = 0; x < numOfElevations; x++)
		{
			for(int y = 0; y < 2; y++)
			{
				//TODO add some other stuff in here about checking sea levels and stuff...
				UVTextures[x,y] = new Texture2D(120,240);
				TextureHelper.Copy(ref UVTextures[x,y],planetBiomes[x/numOfElevations*numOfBiomes].texture);
			}
		}
		//combine the UVtexture array into a map
		for(int x = 0; x < numOfElevations; x++)
		{
			for(int y = 0; y < 2; y++)
			{
				for(int xx = 0; xx < 120; xx++)
				{
					for(int yy = 0; yy < 240; yy++)
					{
						UVMap.SetPixel(x*120 + xx, y*240 + yy, UVTextures[x,y].GetPixel(xx,yy));
					}
				}
			}
		}
		UVMap.Apply ();

		/*********************************************************
		 * Assign all of the changes and clean up
		 * *******************************************************/
		//assign the meshcollider
		Material renderMaterial = new Material (shader);
		renderMaterial.mainTexture = UVMap;
		newMesh.uv = UV;
		gameObject.GetComponent<MeshFilter> ().mesh = newMesh;
		transform.renderer.material = renderMaterial;
		
		gameObject.AddComponent <MeshCollider> ();
	}
	
	/************************************************************
	 * Check to see if planet has been explored and manage biomes
	 * *********************************************************/
	public virtual void Update () 
	{
		//Move planet in orbit around parent body
		transform.RotateAround(transform.parent.position, Vector3.forward,OrbitSpeed*Time.deltaTime);

		if(explored && !hasBeenRevealed)
		{
			//transform.renderer.enabled = true;
		}
		else
		{
			//transform.renderer.enabled = false;
		}
	}
}
