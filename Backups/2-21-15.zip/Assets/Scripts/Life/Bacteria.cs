using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class Bacteria: Organism
{
	public int activeCells;

	public Cell[,] cellBody = new Cell[10,10];
	public Cell[,] previousBody = new Cell[10,10];
	public bool[,] cellChanged = new bool[10,10];

	public Bacteria()
	{
	}

	public Bacteria(Cell[,] bacteria)
	{
		Array.Copy(bacteria,0,cellBody,0,100);
	}

	public Bacteria(Bacteria copy)
	{
		Array.Copy (copy.cellBody, 0, cellBody, 0, 100);
		Array.Copy (copy.previousBody, 0, previousBody, 0, 100);
		Array.Copy (copy.cellChanged, 0, cellChanged, 0, 100);

		genus = copy.genus;
		species = copy.species;

		quantity = copy.quantity;
		
		TextureHelper.Copy(ref sprite,copy.sprite);

		used = new Dictionary<string,float> (copy.used);
		available = new Dictionary<string,float> (copy.available);
		resourceIn = new Dictionary<string,float> (copy.resourceIn);
		resourceOut = new Dictionary<string,float> (copy.resourceOut);
		
		energyIn = new Dictionary<string,float> (copy.energyIn);
		energyOut = new Dictionary<string,float> (copy.energyOut);
	}

	public void setSimulationInputs(BiomeResources mineral,PlanetResources gas, EnergyResources energies)
	{
		/***************************************************
		 * Get the surrounding environment
		 * *************************************************/
		foreach(KeyValuePair<string,float> resource in mineral.mineralQuantities)
		{
			available[resource.Key] = resource.Value;
			for(int x = 0; x < 10; x++)
			{
				for(int y = 0; y < 10; y++)
				{
					cellBody[x,y].available[resource.Key] = resource.Value;
				}
			}
		}
		foreach(KeyValuePair<string,float> resource in gas.gasQuantities)
		{
			available[resource.Key] = 1;//resource.Value;
			for(int x = 0; x < 10; x++)
			{
				for(int y = 0; y < 10; y++)
				{
					cellBody[x,y].available[resource.Key] = 1;//resource.Value;
				}
			}
		}
		foreach(KeyValuePair<string,float> resource in energies.energyQuantities)
		{
			available[resource.Key] = resource.Value;
			for(int x = 0; x < 10; x++)
			{
				for(int y = 0; y < 10; y++)
				{
					cellBody[x,y].available[resource.Key] = resource.Value;
				}
			}
		}
		//copy it to each cell in the grid
	}

	public void Simulate()
	{
		/*************************************************************
		 * Update the grid so that all numbers are correct
		 * **********************************************************/
		for(int x = 0; x < 10; x++)
		{
			for(int y = 0; y < 10; y++)
			{
				if(cellBody[x,y] != null)
				{
					if(cellBody[x,y].type != null)
					{
						//UpdateCell(x,y,cellBody[x,y]);
						//cellChanged[x,y] = false;
					}
				}
			}
		}
		/***********************************************************
		 * Turn the bacteria into a black box
		 * ********************************************************/
		for(int x = 0; x < 10; x++)
		{
			for(int y = 0; y < 10; y++)
			{
				if(cellBody[x,y] != null)
				{
					foreach(string resource in Control.minerals)
					{
						resourceIn[resource] += (cellBody[x,y].used[resource]-used[resource])/9;
						resourceOut[resource] += (cellBody[x,y].available[resource]-available[resource])/9;
					}
					foreach(string resource in Control.gasses)
					{
						resourceIn[resource] += (cellBody[x,y].used[resource]-used[resource])/9;
						resourceOut[resource] += (cellBody[x,y].available[resource]-available[resource])/9;
					}
					foreach(string resource in Control.organics)
					{
						resourceIn[resource] += (cellBody[x,y].used[resource])/9;
						resourceOut[resource] += (cellBody[x,y].available[resource])/9;
					}
					foreach(string energy in Control.energies)
					{
						energyIn[energy] += (cellBody[x,y].used[energy]-used[energy])/9;
						energyOut[energy] += (cellBody[x,y].available[energy]-available[energy])/9;
					}
				}
			}
		}
		foreach(KeyValuePair<string,float> resource in resourceIn)
		{
			if(resourceOut[resource.Key] < 0) resourceOut[resource.Key] = 0;
		}
		foreach(KeyValuePair<string,float> resource in resourceOut)
		{
			if(resourceIn[resource.Key] < 0) resourceIn[resource.Key] = 0;
		}
		Render ();
	}

	public void Simulate(BiomeResources mineral,PlanetResources gas, EnergyResources energies)
	{	
		setSimulationInputs (mineral, gas, energies);
		Simulate ();
	}

	/***********************************************
	 * Update the values of the new cell
	 * //TODO Work in the various types of cells
	 * ***********************************************/
	public void UpdateCell(int x, int y, Cell newCell)
	{
		Vector2[] directions = new Vector2[9]
		{
			new Vector2(0,0),
			new Vector2(1,1),
			new Vector2(1,0),
			new Vector2(0,1),
			new Vector2(-1,-1),
			new Vector2(0,-1),
			new Vector2(-1,0),
			new Vector2(1,-1),
			new Vector2(-1,1)
		};	
		if(cellBody[x,y] != null)previousBody [x, y] = new Cell (cellBody [x, y]);
		else previousBody[x,y] = new Cell();

		cellBody [x, y] = new Cell (newCell);
		//set the flag that this cell has already recieved an update
		cellBody [x, y].updated = true;
		
		//Reset the cell's stored values to what was previously in the cell
		cellBody[x,y].available = new Dictionary<string,float>(previousBody[x,y].available);
		cellBody[x,y].used = new Dictionary<string,float>(previousBody[x,y].used);

		//for all possibly effected cells
		/********************************************
		 * Producer
		 * ***************************************/
		/**************************************************************************
		 * Calculate how much outside resources are available to this cell
		 * ******************************************************************/
		if(newCell.type == "Producer" || previousBody[x,y].type == "Producer")
		{
			foreach(string energy in Control.energies)
			{
				foreach(KeyValuePair<string,string> recipe in Recipes.recipes[energy].inOut)
				{
					foreach(Vector2 dir in directions)
					{
						int dirx = x+(int)dir.x;
						int diry = y+(int)dir.y;
						Debug.Log("IN: " + recipe.Key + " Out " + recipe.Value);
						if(dirx >= 0 && dirx < 10 && diry >= 0 && diry < 10)
						{
							/************************************************************************************
							 * Set The adjacent Cells to appropriate values for each different type of cell
							 * ****************************************************************************/
							//if the location doesn't contain a cell create a blank one
							if(cellBody[dirx,diry] == null) 
								cellBody[dirx,diry] = new Cell();

							//Set the amount of resources being used
							float input =
								(cellBody[x,y].resourceIn[recipe.Key]*cellBody[x,y].available[recipe.Key]) - 
									(previousBody[x,y].resourceIn[recipe.Key]*previousBody[x,y].available[recipe.Key]);

							cellBody[dirx,diry].used[recipe.Key] += input;
						
							float output = 
								(cellBody[x,y].resourceOut[recipe.Value]*cellBody[x,y].resourceIn[recipe.Key]*cellBody[x,y].available[recipe.Key]) - 
									(previousBody[x,y].resourceOut[recipe.Value] * previousBody[x,y].resourceIn[recipe.Key]*previousBody[x,y].available[recipe.Key]);

							Debug.Log(input + " " + output);
							cellBody[dirx,diry].available[recipe.Value] += output;
						}
					}
				}
			}
		}

		/******************************************
		 * Transport
		 * //TODO figure out how to make chains...
		 * ****************************************/
		if(newCell.type == "Transport" || previousBody[x,y].type == "Transport")
		{
			foreach(KeyValuePair<string,float> resource in cellBody[x,y].resourceIn)
			{
				float output = (cellBody[x,y].available[resource.Key]*cellBody[x,y].resourceOut[resource.Key]) - 
					(previousBody[x,y].available[resource.Key]*previousBody[x,y].resourceOut[resource.Key]);
				float input = (cellBody[x,y].used[resource.Key]*(cellBody[x,y].resourceOut[resource.Key])) - 
					(previousBody[x,y].used[resource.Key]*(previousBody[x,y].resourceOut[resource.Key]));
				foreach(Vector2 dir in directions)
				{
					int dirx = x+(int)dir.x;
					int diry = y+(int)dir.y;
					if(dirx >= 0 && dirx < 10 && diry >= 0 && diry < 10)
					{
						if(output == input && cellBody[dirx,diry].available[resource.Key] == cellBody[dirx,diry].used[resource.Key])
						{
							cellBody[dirx,diry].available[resource.Key] += cellBody[x,y].available[resource.Key]-previousBody[x,y].available[resource.Key];
							cellBody[dirx,diry].used[resource.Key] += cellBody[x,y].available[resource.Key]-previousBody[x,y].available[resource.Key];
						}
						else
						{
							cellBody[dirx,diry].available[resource.Key] += output - input;
							cellBody[dirx,diry].used[resource.Key] += output - input;
						}
						//TODO bandage fix this
						if(cellBody[dirx,diry].available[resource.Key] < 0) cellBody[dirx,diry].available[resource.Key] = 0;
						if(cellBody[dirx,diry].used[resource.Key] < 0) cellBody[dirx,diry].used[resource.Key] = 0;
					}
				}
			}
		}
		
		/****************************************
		 * null
		 * ***************************************/
		//if a cell is being removed re-calculate for what used to be in that location
		if(newCell.type == null)
		{
			foreach(Vector2 dir in directions)
			{
				int dirx = x+(int)dir.x;
				int diry = y+(int)dir.y;
				if(dirx >= 0 && dirx < 10 && diry >= 0 && diry < 10)
				{
					if(cellBody[dirx,diry].type != null)
						UpdateCell(dirx,diry,cellBody[dirx,diry]);
				}
			}
		}
	}
	
	/**************************************************
	 * Render the organism to show what the in game object will look like
	 * *******************************************************/

	public void Render()
	{
		Vector2[] directions = new Vector2[8]
		{
			new Vector2(1,1),
			new Vector2(1,0),
			new Vector2(0,1),
			new Vector2(-1,-1),
			new Vector2(0,-1),
			new Vector2(-1,0),
			new Vector2(1,-1),
			new Vector2(-1,1)
		};	

		Texture2D newSprite = new Texture2D(320,320);
		Texture2D smallTransparent = new Texture2D (32, 32);
		smallTransparent.SetPixels (TextureHelper.newImage (32, 32, new Color(0,0,0,0)));
		smallTransparent.Apply ();

		Texture2D[,] resizedCell = new Texture2D[10, 10];
		Texture2D[,] cellShader = new Texture2D[10, 10];
		Texture2D[,] cellConnect = new Texture2D[10, 10];

		TextureHelper.Copy (ref newSprite, CellTextures.transparent);
		/*******************************************************************************************
		 * Copy the data from all of the cells and put it into an array that will be further manipulated
		 * ******************************************************************************************/
		for(int x = 0; x < 10; x++)
		{
			for(int y = 0; y < 10; y++)
			{
				if(cellBody[x,y] != null)
				{
					if(cellBody[x,y].type != null)
					{
						resizedCell[x,y] = new Texture2D(320,320);
						TextureHelper.Copy(ref resizedCell[x,y],cellBody[x,y].sprite);
						TextureScale.Point(resizedCell[x,y],32,32);
						//TODO look at all of the adjacent cells to determine how to edit the cell. 

						resizedCell[x,y].Apply();

						//initialize the shader
						cellShader[x,y] = new Texture2D(32,32);
						TextureHelper.Copy(ref cellShader[x,y],CellTextures.center);

						//initialize the interconnect
						cellConnect[x,y] = new Texture2D(32,32);
						TextureHelper.Copy(ref cellConnect[x,y],CellTextures.center);

						foreach(Vector2 dir in directions)
						{
							int dirx = x + (int)dir.x;
							int diry = y + (int)dir.y;
							//check if the neighbor is an edge or a corner
							//if either direction is 0 its an edge
							//Make sure that it is within the grid
							if(dirx >= 0 && dirx < 10 && diry >= 0 && diry < 10)
							{
								if((int)dir.x == 0 || (int)dir.y == 0)
								{
									//make sure a valid cell exists in that location
									if(cellBody[dirx,diry] != null)
									{
										//if it's the same cell combine the filters
										if(cellBody[x,y].name == cellBody[dirx,diry].name)
										{
											//Debug.Log("edge found");
											TextureHelper.Copy(ref cellShader[x,y],TextureHelper.CombineTextures(
												cellShader[x,y],TextureHelper.rotate(CellTextures.edge,dir)));
										}
										//if it's a null cell add the next shader
										else if(cellBody[dirx,diry].type == null)
										{
											//Debug.Log("Blank edge found");
											TextureHelper.Copy(ref cellConnect[x,y],TextureHelper.CombineTextures(
												cellConnect[x,y],TextureHelper.rotate(CellTextures.edge,dir)));
										}
									}
									else
									{
										//Debug.Log("Blank edge found");
										TextureHelper.Copy(ref cellConnect[x,y],TextureHelper.CombineTextures(
												cellConnect[x,y],TextureHelper.rotate(CellTextures.edge,dir)));
									}
								}
								//otherwise its a corner
								else
								{
									//make sure a valid cell exists in that location
									if(cellBody[dirx,diry] != null)
									{
										//if it's the same cell combine the filters
										if(cellBody[x,y].name == cellBody[dirx,diry].name)
										{
											//Debug.Log("corner found");
											TextureHelper.Copy(ref cellShader[x,y],TextureHelper.CombineTextures(
												cellShader[x,y],TextureHelper.rotate(CellTextures.corner,dir)));
										}
										//if it's a null cell add the next shader
										else if(cellBody[dirx,diry].type == null)
										{
											//Debug.Log("Blank corner found");
											TextureHelper.Copy(ref cellConnect[x,y],TextureHelper.CombineTextures(
												cellConnect[x,y],TextureHelper.rotate(CellTextures.corner,dir)));
										}
									}
									else
									{
										//Debug.Log("Blank corner found");
										TextureHelper.Copy(ref cellConnect[x,y],TextureHelper.CombineTextures(
											cellConnect[x,y],TextureHelper.rotate(CellTextures.corner,dir)));
									}
								}
								//apply the shaders
								cellShader[x,y].Apply();
								cellConnect[x,y].Apply();
							}
						}

						//Combing the interconnect with the 
						//TODO maybe split this up...
						TextureHelper.Copy(ref cellConnect[x,y],TextureHelper.CombineTextures(
							smallTransparent,CellTextures.interconnect,cellConnect[x,y]));

						//TextureHelper.Copy(ref cellConnect[x,y],smallTransparent);
						cellConnect[x,y].Apply();

						TextureHelper.Copy(ref resizedCell[x,y],TextureHelper.CombineTextures(
							resizedCell[x,y],cellConnect[x,y],cellShader[x,y]));
						                 
						resizedCell[x,y].Apply();

						for(int xx = 0; xx < 32; xx++)
						{
							for(int yy = 0; yy < 32; yy++)
							{
								newSprite.SetPixel((32*x)+xx,320-((32*y)+yy),resizedCell[x,y].GetPixel(xx,yy));
							}
						}
					}
				}
			}
		}

		newSprite.Apply ();
		TextureHelper.Copy (ref sprite, newSprite);
	}

	public void Evolve()
	{
	}
}