using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public static partial class GeneticEngineering
{
	//A list of all the saved bacteria in the game
	private static Dictionary<string,Bacteria> savedBacteria = new Dictionary<string,Bacteria>();

	public static Bacteria tempBacteria = new Bacteria();
	private static Dictionary<string,float> netResources = new Dictionary<string,float>();
	private static bool simulated = false;
	//the actively selected cell
	private static Cell activeCell = null;

	private static void bacteriaEngineering()
	{
		/*******
		 * Leftmost Collumn
		 * *****/
		//display all saved cells which can be added to the bacteria organism
		GUI.BeginGroup (new Rect(8,40,320,Screen.height-40));
		GUI.Label(new Rect(0,0,80,40),"Genus:");
		name = GUI.TextField (new Rect(80,0,260,20),name);
		scroll[0] = GUI.BeginScrollView (new Rect(8,40,240,Screen.height-80), scroll[0], new Rect(0, 0, 240,outputTextRows[0]*36));
		int i = 0;
		foreach(KeyValuePair<string,Cell> Cell in CellEngineering.savedCells)
		{
			GUI.DrawTexture(new Rect(0,30*i,30,30),Cell.Value.sprite, ScaleMode.ScaleToFit);
			if(GUI.Button(new Rect(40,30*i,200,24),Cell.Key)) activeCell = Cell.Value;
			i++;
		}
		outputTextRows [0] = i;
		GUI.EndScrollView ();
		if(GUI.Button(new Rect(0,Screen.height-70,120,30),"New Cell"))
		{
			//CLose this window and Open up cell engineering window
			GUIMain.windowDisplay[4] = false;
			GUIMain.windowDisplay[6] = true;
		}
		if(GUI.Button(new Rect(120,Screen.height-70,120,30),"Clear Grid"))
		{
			ClearGrid();
		}
		GUI.EndGroup ();
		
		/**************************
		 * Viewing Window
		 * ***********************/
		Vector2 viewWindow = new Vector2(Screen.height,Screen.height);
		GUI.BeginGroup (new Rect(260,40,viewWindow.x,viewWindow.y));

		//Check to see if viewing render or editing
		//editing view
		//TODO check to make sure cell is valid before placement
		if(Input.GetMouseButtonDown (0))
		{
			int xPos = Mathf.FloorToInt((Input.mousePosition.x-260)/(0.1f*viewWindow.x));
			int yPos = Mathf.FloorToInt((-Input.mousePosition.y+Screen.height-40)/(0.1f*viewWindow.y));
			if(xPos > -1 && xPos < 10 && yPos > -1 && yPos < 10)
			{
				simulated = false;
				tempBacteria.UpdateCell(xPos,yPos,activeCell);
			}
		}
		if(Input.GetMouseButtonDown(1))
		{
			int xPos = Mathf.FloorToInt((Input.mousePosition.x-260)/(0.1f*viewWindow.x));
			int yPos = Mathf.FloorToInt((-Input.mousePosition.y+Screen.height-40)/(0.1f*viewWindow.y));
			if(xPos > -1 && xPos < 10 && yPos > -1 && yPos < 10)
			{
				simulated = false;
				tempBacteria.UpdateCell(xPos,yPos,new Cell());
			}
		}
		for(int x = 0; x < 10; x++)
		{
			for(int y = 0; y < 10; y++)
			{
				if(tempBacteria.cellBody[x,y] != null)
				{
					//Draw all of the cells
					GUI.DrawTexture(new Rect(x*0.1f*viewWindow.x,y*0.1f*viewWindow.y,0.1f*viewWindow.x,0.1f*viewWindow.y),tempBacteria.cellBody[x,y].sprite);
					//Free the cell up for another update
					GUI.Label(new Rect(x*0.1f*viewWindow.x,y*0.1f*viewWindow.y,0.1f*viewWindow.x,0.1f*viewWindow.y),
					          tempBacteria.cellBody[x,y].available["Clorophyll"].ToString("F2"));
					GUI.Label(new Rect(x*0.1f*viewWindow.x,y*0.1f*viewWindow.y+20,0.1f*viewWindow.x,0.1f*viewWindow.y),
					          tempBacteria.cellBody[x,y].used["Clorophyll"].ToString("F2"));
					if(tempBacteria.previousBody[x,y] != null)
					{
						GUI.Label(new Rect(x*0.1f*viewWindow.x,y*0.1f*viewWindow.y+40,0.1f*viewWindow.x,0.1f*viewWindow.y),
					          tempBacteria.previousBody[x,y].available["Clorophyll"].ToString("F2"));
					GUI.Label(new Rect(x*0.1f*viewWindow.x,y*0.1f*viewWindow.y+60,0.1f*viewWindow.x,0.1f*viewWindow.y),
					          tempBacteria.previousBody[x,y].used["Clorophyll"].ToString("F2"));
					}
					tempBacteria.cellBody[x,y].updated = false;
				}
			}
		}
		GUI.EndGroup ();
		/*************************
		 * RightMost Column holds stats and information about specific bacteria
		 * **********************/
		//rendered view
		GUI.DrawTexture(new Rect(Screen.width-320,40,320,320),tempBacteria.sprite);
		//Holds the information about the current organism
		GUI.BeginGroup (new Rect(Screen.width-320,360,320,Screen.height-400));
		GUI.Box (new Rect(0,0,320,Screen.height-400),"");
		if(!simulated) GUI.Label(new Rect(0,0,320,80),"Needs to be Simulated");
		else
		{
			GUI.Label(new Rect(0,0,160,80),"Resources");
			GUI.Label(new Rect(160,0,160,80),"Abilities");
			/**************************************************************
			 * Displays the actual information about the organism
			 * -Resources
			 * ****************************************************************/
			scroll[1] = GUI.BeginScrollView (new Rect(0,40,320,Screen.height-400), scroll[1], new Rect(0, 0, 320,outputTextRows[1]*36));
			i = 0;
			//Sort by value so that it's easiest to know what resources are needed
			GUI.Label (new Rect (0, 20 * i, 160, 20), "Resource In");
			i++;
			foreach(KeyValuePair<string,float> resource in tempBacteria.resourceIn)
			{
				if(resource.Value != 0)
				{
					GUI.Label (new Rect (0, 20 * i, 160, 20), resource.Value.ToString("F2") + " " + resource.Key);
					i++;
				}
			}
			i++;
			GUI.Label (new Rect (0, 20 * i, 160, 20), "Energy In");
			i++;
			//Sort by value so that it's easiest to know what resources are needed
			foreach(KeyValuePair<string,float> resource in tempBacteria.energyIn)
			{
				if(resource.Value != 0)
				{
					GUI.Label (new Rect (0, 20 * i, 160, 20), resource.Value.ToString("F2") + " " + resource.Key);
					i++;
				}
			}
			i++;
			GUI.Label (new Rect (0, 20 * i, 160, 20), "Resource Out");
			i++;
			//Sort by value so that it's easiest to know what resources are needed
			foreach(KeyValuePair<string,float> resource in tempBacteria.resourceOut)
			{
				if(resource.Value != 0)
				{
					GUI.Label (new Rect (0, 20 * i, 160, 20), resource.Value.ToString("F2") + " " + resource.Key);
					i++;
				}
			}
			i++;
			GUI.Label (new Rect (0, 20 * i, 160, 20), "Energy Out");
			i++;
			//Sort by value so that it's easiest to know what resources are needed
			foreach(KeyValuePair<string,float> resource in tempBacteria.energyOut)
			{
				if(resource.Value != 0)
				{
					GUI.Label (new Rect (0, 20 * i, 160, 20), resource.Value.ToString("F2") + " " + resource.Key);
					i++;
				}
			}
			outputTextRows [1] = i;
		/**********************************************************
		 * -Abilities
		 * ****************************************************************/
			i = 0;
			GUI.Label (new Rect (160, 20 * i, 160, 20), "Conditions");
			i++;
			foreach(KeyValuePair<string,float> resource in tempBacteria.resourceIn)
			{
				if(resource.Value != 0)
				{
					GUI.Label (new Rect (160, 20 * i, 160, 20), resource.Value.ToString("F2") + " " + resource.Key);
					i++;
				}
			}
			i++;
			GUI.Label (new Rect (160, 20 * i, 160, 20), "Special");
			i++;
			//Sort by value so that it's easiest to know what resources are needed
			foreach(KeyValuePair<string,float> resource in tempBacteria.energyIn)
			{
				if(resource.Value != 0)
				{
					GUI.Label (new Rect (160, 20 * i, 160, 20), resource.Value.ToString("F2") + " " + resource.Key);
					i++;
				}
			}
			GUI.EndScrollView ();
		}
		GUI.EndGroup ();
		/*******************************************************
		 * Control Buttons
		 * ***************************************************/
		if(GUI.Button(new Rect(Screen.width-320,Screen.height-60,160,30),"Render"))
		{
			if(OrganismIsValid())
			{
				//renders the organism
				Debug.Log ("buttonPushed...");
				renderBacteria();
			}
		}
		if(GUI.Button(new Rect(Screen.width-160,Screen.height-60,160,30),"Simulate"))
		{
			if(OrganismIsValid())
			{
				//Simulates the organism for more accurate values
				simulateBacteria();
			}
		}
		if(GUI.Button(new Rect(Screen.width-320,Screen.height-30,160,30),"Create"))
		{
			if(OrganismIsValid())
			{
				//Actually create the organism and load it the the main scene
				simulateBacteria();
				tempBacteria.genus = name;
				tempBacteria.species = "Ingeniare";
				tempBacteria.quantity = 100;
				//save the bacteria for later use
				savedBacteria.Add(name,tempBacteria);
				//load it to the main control and set the flag for placing creature
				Control.addBacteria = true;
				Control.newBacteria = new Bacteria(tempBacteria);
				GUIMain.windowDisplay[4] = false;
			}
		}
	}

	public static void ClearGrid()
	{
		//CLose this window and Open up cell engineering window
		for(int x = 0; x < 10; x ++)
		{
			for(int y = 0; y < 10; y++)
			{
				GeneticEngineering.tempBacteria.cellBody[x,y] = new Cell();
				GeneticEngineering.tempBacteria.cellBody[x,y].sprite = CellTextures.transparent;
			}
		}
		tempBacteria.setSimulationInputs(idealMinerals,idealGasses,idealEnergies);
	}

	private static bool OrganismIsValid()
	{
		bool pass = true;
		List<Vector2> activeCells = new List<Vector2>();
		Vector2[] directions = new Vector2[8]
		{new Vector2(1,1),
			new Vector2(1,0),
			new Vector2(0,1),
			new Vector2(-1,-1),
			new Vector2(0,-1),
			new Vector2(-1,0),
			new Vector2(1,-1),
			new Vector2(-1,1),
		};
		//TODO run some checks to make sure the organism is valid
		return pass;
	}

	private static bool CellIsValid(int x, int y)
	{
		bool pass = false;

		Vector2[] directions = new Vector2[8]
		   {new Vector2(1,1),
			new Vector2(1,0),
			new Vector2(0,1),
			new Vector2(-1,-1),
			new Vector2(0,-1),
			new Vector2(-1,0),
			new Vector2(1,-1),
			new Vector2(-1,1),
		};
		//check to see if it passes the resource test
		return pass;
	}

	private static void renderBacteria()
	{
		tempBacteria.Render ();
	}

	private static void simulateBacteria()
	{
		tempBacteria = new Bacteria (tempBacteria.cellBody);
		tempBacteria.Simulate(idealMinerals,idealGasses,idealEnergies);
		simulated = true;
	}
}
