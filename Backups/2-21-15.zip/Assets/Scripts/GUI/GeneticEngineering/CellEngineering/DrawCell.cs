using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public static partial class CellEngineering
{
	public static IEnumerator drawCell()
	{
		//Producer
		if(cellDisplay[0])
		{
			TextureHelper.Copy(ref tempCell.sprite,CellTextures.textures[cellName[0]]);
			yield return null;
			foreach(KeyValuePair<string,float> resource in tempCell.resourceOut)
			{
				if(resource.Value>0)tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures[resource.Key],tempCell.sprite,0.5f+resource.Value/4);
				tempCell.sprite.Apply();
			}
			yield return null;
			foreach(KeyValuePair<string,float> resource in tempCell.energyOut)
			{
				if(resource.Value>0 && resource.Key != "Life")tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures[resource.Key],tempCell.sprite,0.5f+resource.Value/4);
				tempCell.sprite.Apply();
			}
			rendered = true;
			yield return null;
		}
		//Transport
		else if(cellDisplay[1])
		{
			TextureHelper.Copy(ref tempCell.sprite,CellTextures.textures[cellName[1]]);
			yield return null;
			foreach(KeyValuePair<string,float> resource in tempCell.resourceOut)
			{
				if(resource.Value>0)tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures[resource.Key],tempCell.sprite,0.5f+resource.Value/4);
				tempCell.sprite.Apply();
			}
			yield return null;
			foreach(KeyValuePair<string,float> resource in tempCell.energyOut)
			{
				if(resource.Value>0 && resource.Key != "Life")tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures[resource.Key],tempCell.sprite,0.5f+resource.Value/4);
				tempCell.sprite.Apply();
			}
			rendered = true;
			yield return null;
		}
		//Nueral
		else if(cellDisplay[2])
		{
			TextureHelper.Copy(ref tempCell.sprite,CellTextures.textures[cellName[2]]);
			yield return null;
			foreach(KeyValuePair<string,float> resource in tempCell.resourceOut)
			{
				if(resource.Value>0)tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures[resource.Key],tempCell.sprite,0.5f+resource.Value/4);
				tempCell.sprite.Apply();
			}
			yield return null;
			foreach(KeyValuePair<string,float> resource in tempCell.energyOut)
			{
				if(resource.Value>0 && resource.Key != "Life")tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures[resource.Key],tempCell.sprite,0.5f+resource.Value/4);
				tempCell.sprite.Apply();
			}
			rendered = true;
			yield return null;
		}
		//Utility
		else if(cellDisplay[3])
		{
			TextureHelper.Copy(ref tempCell.sprite,CellTextures.textures[cellName[3]]);
			yield return null;
			foreach(KeyValuePair<string,float> resource in tempCell.resourceOut)
			{
				if(resource.Value>0)tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures[resource.Key],tempCell.sprite,0.5f+resource.Value/4);
				tempCell.sprite.Apply();
			}
			yield return null;
			foreach(KeyValuePair<string,float> resource in tempCell.energyOut)
			{
				if(resource.Value>0 && resource.Key != "Life")tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures[resource.Key],tempCell.sprite,0.5f+resource.Value/4);
				tempCell.sprite.Apply();
			}
			rendered = true;
			yield return null;
		}
	}
}
