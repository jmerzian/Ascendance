﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

/****************************************
 * TODO LIST:
 * Derpy at end of circle...
 * adjust size and color of atmosphere and water according to available resources
 * Fractal subdivide to add additional texture to planet for aesthetic purposes
 * *************************************/
public class Planet : MonoBehaviour
{
	/*********************************************************************************
	 * variables describing the planet
	 * ******************************************************************************/
	public string planetType;

	public float Radius;
	public float Orbit;
	public int startAngle;
	public float OrbitSpeed;

	public bool explored;

	/**************************************************************************
	 * Describing the planet mesh
	 * ************************************************************************/
	private Mesh mesh;
	private Vector3[] Vertice;
	private Vector2[] UV;
	private int[] triangles;
	private int[] faceTriangles;

	private Mesh waterMesh;
	private Vector3[] waterVertice;
	private Vector2[] waterUV;
	private int[] waterTriangles;
	private int[] waterFaceTriangles;

	public Shader shader;
	public Color color;
	public Texture defaultTex;
	private Texture2D UVMap;// = new Texture2D(240,240);

	private GameObject atmosphere;
	private GameObject liquid;
	public Sprite back;
	public Sprite atmo;

	/***************************************************************************
	 * Values describing the resources and location of said resources
	 * *************************************************************************/
	public PlanetResources resources;
	//make resources addable from the main unity window
	public float[] newResources;

	//Information about biome elevations 5 per biome
	public int numOfElevations;
	public float heightPerElevation;
	public int[] elevation;
	public int elevationRange;

	//Information about liquid levels
	public int seaLevel;

	/*****************************************************************************
	 * Hold information about the biomes and creatures living on them
	 * **************************************************************************/
	//Dictionary holding vertice values which point to an int...
	public Dictionary<Vector3,int> vectorMap = new Dictionary<Vector3,int>();

	//that int points to a biome...
	public Dictionary<int,Biome> planetBiomes = new Dictionary<int,Biome>();
	public Dictionary<int,LifeResources> planetLife = new Dictionary<int,LifeResources>();

	//...and to a UV coordinate
	private Dictionary<int,Vector2> biomeMap = new Dictionary<int, Vector2> ();

	//interactivity functions
	private bool hasBeenRevealed = false;

	/***********************************************************
	 * Initialize planet to be at x position, and set up biomes
	 * *********************************************************/
	public void Init() 
	{
		/******************************************
		 * Initialize the meshes
		 * *****************************************/
		Mesh newMesh = new Mesh ();
		Vertice = new Vector3[numOfElevations * 3 + 1];
		UV = new Vector2[numOfElevations * 3 + 1];
		triangles = new int[numOfElevations * 12];

		Mesh waterMesh = new Mesh ();
		waterVertice = new Vector3[numOfElevations * 3 +1];
		waterUV = new Vector2[numOfElevations * 3 + 1];
		waterTriangles = new int[numOfElevations * 12];		

		/****************************************
		 * Create the main mesh
		 * ************************************/
		elevation = new int[numOfElevations];
		int numOfBiomes = numOfElevations / 5;

		//Create the vertice locations
		for (int i = 0; i < numOfElevations; i++)
		{
			//set each of the starting elevations to a random value
			elevation[i] = Random.Range(-elevationRange,elevationRange);
			float angle = i*2*Mathf.PI/numOfElevations;
			for(int j = 0; j < 3; j++)
			{
				//set vector position
				float radius = Radius - j*j*Radius/20 + elevation[i]*Radius*(heightPerElevation/50);
				Vertice[j*numOfElevations + i] = new Vector3((radius)*Mathf.Cos(angle),(radius)*Mathf.Sin(angle),j*Radius/10);

				UV[j*numOfElevations + i] = new Vector2((float)i/(float)(numOfElevations-1),(float)j/3);
				//Debug.Log("adding UV " + (j*numOfElevations + i).ToString());

				//add vector to map mapping it's coordinates to a biome so long as it isn't an edge
				int biomeNum = ((int)(5*((float)i/(float)numOfElevations)));
	
				vectorMap.Add(Vertice[j*numOfElevations + i],biomeNum);
			}
			//set the UV map for the center and that wierd odd one...
		}
		Vertice[3*numOfElevations]= new Vector3(0,0,2*Radius/10);

		//TODO if this works fix it so that it works with the last part... because that is currently a little bit wierd...

		for(int i = 0; i < numOfElevations; i++)
		{
			for(int j = 0 ; j < 2; j++)
			{
				//SET THE TRIANGLES
				//triangle 1
				triangles[6*(i+j*numOfElevations)] = i + j*numOfElevations; 
				triangles[6*(i+j*numOfElevations)+1] = (i+1)+j*numOfElevations; 
				triangles[6*(i+j*numOfElevations)+2] = i+(j+1)*numOfElevations;
				//Debug.Log("Triangle " + ((6*i+j*numOfElevations)/3).ToString() + " " + new Vector3(triangles[6*i+j*numOfElevations],triangles[6*i+1+j*numOfElevations],triangles[6*i+2+j*numOfElevations]));
				//triangle two)
				if((i+1) != numOfElevations)
				{
					triangles[6*(i+j*numOfElevations)+5] = (i+1)+j*numOfElevations; 
					triangles[6*(i+j*numOfElevations)+4] = i+numOfElevations+j*numOfElevations; 
					triangles[6*(i+j*numOfElevations)+3] = (i+1)+(j+1)*numOfElevations;
				}
				else
				{
					triangles[6*(i+j*numOfElevations)+3] = i + j*numOfElevations; 
					triangles[6*(i+j*numOfElevations)+4] = j*numOfElevations; 
					triangles[6*(i+j*numOfElevations)+5] = (i+1) +j*numOfElevations;
				}
				//Debug.Log("Triangle " + ((6*i+ 3 +j*numOfElevations)/3).ToString() + " " + new Vector3(triangles[6*i+3+j*numOfElevations],triangles[6*i+4+j*numOfElevations],triangles[6*i+5+j*numOfElevations]));
			}
		}
		//Create the inside face
		faceTriangles = new int[(numOfElevations)*3];
		for(int i = 0; i <numOfElevations; i++)
		{
			//Set the inside face
			faceTriangles[3*i] = numOfElevations*3;
			faceTriangles[3*i+1] = numOfElevations*2 + (i-1);
			faceTriangles[3*i+2] = numOfElevations*2 + (i);
		}

		//assign the mesh the new values
		newMesh.vertices = Vertice;
		newMesh.uv = UV;
		newMesh.triangles = triangles;
		//Subdivide the mesh to add some texture
		newMesh = MeshHelper.fractalSubdivision (newMesh, 1, new Vector3(0.1f,0.1f,0.1f));
		newMesh.RecalculateNormals ();
		/************************************************************************
		 * Add biomes, resources and textures
		 * *********************************************************************/
		resources = new PlanetResources(newResources);

		//Create the biomes
		//Set the textures
		UVMap = new Texture2D (numOfElevations * 120, 480);
		Texture2D[,] UVTextures = new Texture2D[numOfElevations, 3];
		//init texture array
		for(int x = 0; x < numOfElevations; x++)
		{
			for(int y = 0; y < 2; y++)
			{
				UVTextures[x,y] = new Texture2D(120,240);
			}
		}

		//TODO select the used texture based on biome type...
		for(int i = 0; i < numOfBiomes; i++)
		{
			if(planetType == "Active") 
			{
				string biomeType = Control.biomeType[Random.Range(0,Control.biomeType.Count)];
				planetBiomes.Add(i,new Biome(biomeType));
				planetLife.Add(i,planetBiomes[i].life);
				foreach(string resource in Control.minerals)
				{
					float resourceQuantity = Random.Range(0,10);// * BiomeTypes.defaultBiome[biomeType].resources.mineralQuantities[resource];
					planetBiomes[i].resources.mineralQuantities[resource] = resourceQuantity;
				}

				TextureHelper.Copy(ref UVTextures[i*5,0],BiomeTypes.textures[biomeType]);
				//Blend the biomes together
			}
		}
		for(int i = 0; i < numOfBiomes; i++)
		{
			for(int j = 0; j < 5; j++)
			{ 
				int nextIndex = i+1;
				if(nextIndex > numOfBiomes-1) nextIndex = 0;

				if(j == 2)
				{
					//do nothing this texture has already been set...
				}
				if(j == 4 && i != numOfBiomes-1)
				{
					UVTextures[i*5 + j,0] = TextureHelper.CombineTextures(UVTextures[i*5,0],UVTextures[(nextIndex)*5,0],BiomeTypes.Gradient);
				}
				else
				{
					UVTextures[i*5 + j,0] = UVTextures[i*5,0];
				}
				UVTextures[i*5 + j,1] = UVTextures[i*5 + j,0];
			}
		}
		//combine the UVtexture array into a map
		for(int x = 0; x < numOfElevations; x++)
		{
			for(int y = 0; y < 2; y++)
			{
				for(int xx = 0; xx < 120; xx++)
				{
					for(int yy = 0; yy < 240; yy++)
					{
						UVMap.SetPixel((x*120) + xx, (y*240) + yy, UVTextures[x,y].GetPixel(xx,yy));
					}
				}
			}
		}
		UVMap.Apply ();

		/********************************************
		 * TODO Add the water and atmosphere
		 * ****************************************/
		/****************************
		 * Water
		 * *****************************/
		liquid = new GameObject("Water");
		liquid.AddComponent<MeshFilter> ();
		liquid.AddComponent<MeshRenderer> ();

		for(int i = 0; i < numOfElevations; i++)
		{
			float angle = i*2*Mathf.PI/numOfElevations;
			for(int j = 0; j < 3; j++)
			{
				//set vector position
				float radius = Radius - j*j*Radius/20 + seaLevel*Radius*((heightPerElevation)/50);
				waterVertice[j*numOfElevations + i] = new Vector3((radius)*Mathf.Cos(angle),(radius)*Mathf.Sin(angle),j*(Radius)/10.1f);
				waterUV[j*numOfElevations + i] = new Vector2((float)i/(float)numOfElevations,(float)j/2);
			}
		}
		waterVertice[3*numOfElevations]= new Vector3(0,0,2*Radius/10.1f);
		for(int i = 0; i < numOfElevations; i++)
		{
			for(int j = 0 ; j < 2; j++)
			{
				//SET THE waterTriangles
				//triangle 1
				waterTriangles[6*(i+j*numOfElevations)] = i + j*numOfElevations; 
				waterTriangles[6*(i+j*numOfElevations)+1] = (i+1)+j*numOfElevations; 
				waterTriangles[6*(i+j*numOfElevations)+2] = i+(j+1)*numOfElevations;
				//Debug.Log("Triangle " + ((6*i+j*numOfElevations)/3).ToString() + " " + new Vector3(waterTriangles[6*i+j*numOfElevations],waterTriangles[6*i+1+j*numOfElevations],waterTriangles[6*i+2+j*numOfElevations]));
				//triangle two)
				if((i+1) != numOfElevations)
				{
					waterTriangles[6*(i+j*numOfElevations)+5] = (i+1)+j*numOfElevations; 
					waterTriangles[6*(i+j*numOfElevations)+4] = i+numOfElevations+j*numOfElevations; 
					waterTriangles[6*(i+j*numOfElevations)+3] = (i+1)+(j+1)*numOfElevations;
				}
				else
				{
					waterTriangles[6*(i+j*numOfElevations)+3] = i + j*numOfElevations; 
					waterTriangles[6*(i+j*numOfElevations)+4] = j*numOfElevations; 
					waterTriangles[6*(i+j*numOfElevations)+5] = (i+1) +j*numOfElevations;
				}
				//Debug.Log("Triangle " + ((6*i+ 3 +j*numOfElevations)/3).ToString() + " " + new Vector3(waterTriangles[6*i+3+j*numOfElevations],waterTriangles[6*i+4+j*numOfElevations],waterTriangles[6*i+5+j*numOfElevations]));
			}
		}
		//Create the inside face
		waterFaceTriangles = new int[3*(numOfElevations)];
		for(int i = 0; i <numOfElevations; i++)
		{
			//Set the inside face
			waterFaceTriangles[3*i] = numOfElevations*3;
			waterFaceTriangles[3*i+1] = numOfElevations*2 + (i-1);
			waterFaceTriangles[3*i+2] = numOfElevations*2 + (i);
		}
		//assign the mesh the new values
		waterMesh.vertices = waterVertice;
		waterMesh.triangles = waterTriangles;
		waterMesh.RecalculateNormals ();
		//assign the meshcollider
		waterMesh.subMeshCount = 2;
		waterMesh.SetIndices(waterTriangles,MeshTopology.Triangles,0);
		waterMesh.SetIndices(faceTriangles,MeshTopology.Triangles,1);
		
		liquid.GetComponent<MeshFilter> ().mesh = waterMesh;
		liquid.renderer.materials = new Material[]{new Material(BiomeTypes.Water),new Material(BiomeTypes.Water)};
		Color waterColor = new Color (Random.Range (0, 1f), Random.Range (0, 1f), Random.Range (0, 1f), 0.5f);
		liquid.renderer.materials[0].color = waterColor;
		liquid.renderer.materials[1].color = waterColor/2;

		liquid.transform.rotation = Quaternion.Euler (0, 180, 0);
		liquid.transform.position = transform.position;
		liquid.transform.parent = transform;
		
		
		/**************
		 * Atmosphere
		 * ****************/
		atmosphere = new GameObject ("Atmosphere");
		atmosphere.transform.rotation = Quaternion.Euler (0, 180, 0);
		atmosphere.transform.parent = transform;
		Texture2D atmoTexture = new Texture2D (1024, 1024);
		TextureHelper.Copy (ref atmoTexture, BiomeTypes.Atmo);

		SpriteRenderer atmo = atmosphere.AddComponent<SpriteRenderer> ();
		atmo.color = new Color (Random.Range (0, 1f), Random.Range (0, 1f), Random.Range (0, 1f));
		atmo.sprite = Sprite.Create(atmoTexture, new Rect (0,0,1024,1024), new Vector2 (0.5f,0.5f));

		atmosphere.transform.localScale = new Vector3 (Radius/3, Radius/3, Radius/3);
		atmosphere.transform.position = transform.position;

		/*********************************************************
		 * Assign all of the changes and clean up
		 * *******************************************************/
		//assign the meshcollider
		Material renderMaterial = new Material (shader);
		renderMaterial.mainTexture = UVMap;

		Material faceMaterial = new Material (shader);
		faceMaterial.mainTexture = BiomeTypes.Core;

		//Create the submeshes
		newMesh.subMeshCount = 2;
		newMesh.SetIndices(triangles,MeshTopology.Triangles,0);
		newMesh.SetIndices(faceTriangles,MeshTopology.Triangles,1);
		gameObject.GetComponent<MeshFilter> ().mesh = newMesh;

		transform.renderer.materials = new Material[]{renderMaterial,faceMaterial};
		
		gameObject.AddComponent <MeshCollider> ();
		//set up a shere collider so that the planet itself can be selected
		SphereCollider collider = gameObject.AddComponent<SphereCollider> ();
		collider.radius = Radius/2;

		
		//Change the object's position
		transform.position = new Vector3 (transform.parent.position.x+Orbit*Mathf.Cos(startAngle), transform.parent.position.y+Orbit*Mathf.Sin(startAngle), 0);
	}
	
	/************************************************************
	 * Check to see if planet has been explored and manage biomes
	 * *********************************************************/
	public virtual void FixedUpdate () 
	{
		//Move planet in orbit around parent body
		transform.RotateAround(transform.parent.position, Vector3.forward,OrbitSpeed*Time.deltaTime);

		if(explored && !hasBeenRevealed)
		{
			transform.renderer.enabled = true;
		}
		else
		{
			transform.renderer.enabled = false;
		}
	}

	public IEnumerator turnUpdate()
	{
		foreach(Biome biome in planetBiomes.Values)
		{
			yield return StartCoroutine(biome.Update());
			foreach(Bacteria bacteria in biome.life.bacteria.Values)
			{
				foreach(string resource in Control.gasses)
				{
					resources.gasQuantities[resource] += (bacteria.resourceOut[resource] - bacteria.resourceIn[resource]) * bacteria.quantity/1000000;
					if(resources.gasQuantities[resource] < 0) resources.gasQuantities[resource] = 0;
				}
			}
		}
	}
}
