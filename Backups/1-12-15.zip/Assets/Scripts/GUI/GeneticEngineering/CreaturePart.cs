using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class CreaturePart
{
	//name of part... currently not used
	public string name;

	//where the part connects to the next Node
	public Vector2 parentNode = new Vector2();

	//where the children connect, x,y, and rotation
	public List<Vector3> childrenNodes = new List<Vector3>();

	//part sprite and Texture 240 x 240
	public Texture2D sprite;
	public Texture2D texture;

	//object properties
	[HideInInspector]
	public float scale;

	public CreaturePart()
	{
	}

	public CreaturePart(string newName, Vector2 newParent, List<Vector3> newChildren, Texture2D newTexture): this()
	{
		name = newName;
		parentNode = newParent;
		childrenNodes = newChildren;
		sprite = newTexture;
	}

	public CreaturePart(CreaturePart part): this()
	{
		name = part.name;
		parentNode = part.parentNode;
		childrenNodes = part.childrenNodes;
		sprite = part.sprite;
		texture = part.texture;
		scale = part.scale;
	}
}