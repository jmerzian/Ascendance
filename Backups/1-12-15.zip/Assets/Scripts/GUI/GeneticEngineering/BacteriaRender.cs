using UnityEngine;
using System;
using System.Collections.Generic;

public static class BacteriaRender
{
	//list of creature components
	public static Dictionary<string,CreaturePart> mouths = new Dictionary<string,CreaturePart>();
	public static Dictionary<string,CreaturePart> heads = new Dictionary<string,CreaturePart>();
	public static Dictionary<string,CreaturePart> bodies = new Dictionary<string,CreaturePart>();
	public static Dictionary<string,CreaturePart> tails = new Dictionary<string,CreaturePart>();

	public static Texture2D renderCreature(float size, float temperature,float[] movement, float[] nutrients, float[] energy,float[] senses)
	{	
		//The final creation
		CreaturePart finalCreature = new CreaturePart();

		//Frankensteins pieces
		//potentially use a linked list...
		Dictionary<int,List<CreaturePart>> currentParts = new Dictionary<int,List<CreaturePart>>();
		//temporary holder for each group of parts
		Dictionary<int,CreaturePart> parts = new Dictionary<int, CreaturePart>();

		//tails, then bodies, then heads, then mouths
		currentParts.Add(3,tempPart(3,movement,ref BacteriaStrings.movementTypes,ref tails));
		currentParts.Add(2,tempPart(2,energy,ref BacteriaStrings.energyTypes, ref bodies));
   		currentParts.Add(1,tempPart(1,senses,ref BacteriaStrings.senseTypes, ref heads));
    	currentParts.Add(0,tempPart(0,nutrients,ref BacteriaStrings.nutrientTypes, ref mouths));

		//combine all of the sprites together... this takes a while
		//TODO optimize this function, multithreading may be neccesarry
		/*for(int i = 0; i < currentParts.Count; i++)
		{
			parts.Add(i,new CreaturePart());

			//create initial texture data
			int baseWidth = (int)(currentParts[i][0].sprite.width*currentParts[i][0].scale);
			int baseHeight = (int)(currentParts[i][0].sprite.height*currentParts[i][0].scale);
			parts[i].sprite = new Texture2D(baseWidth,baseHeight);

			//set up the parent node... basically copying the first of the parts
			parts[i].parentNode = currentParts[i][0].parentNode;
		
			foreach(CreaturePart part in currentParts[i])
			{
				//position everything in accordance with the parentNode being at (0,0)
				//width of full part * parent - width of small part * parent
				Vector2 parentDim = new Vector2(parts[i].sprite.width,parts[i].sprite.height);
				Vector2 parentNode = new Vector2((parts[i].sprite.width*parts[i].parentNode.x)-(part.sprite.width*part.parentNode.x*part.scale),
				                                 (parts[i].sprite.height*parts[i].parentNode.y)-(part.sprite.height*part.parentNode.y*part.scale));
				Rect parentPos = new Rect(0,0,parentDim.x,parentDim.y);
				Rect partPos = new Rect(parentNode.x,parentNode.y,part.sprite.width*part.scale,part.sprite.height*part.scale);
				//finally combine the textures together
				TextureHelper.combineTextures(part.sprite,partPos,parts[i].sprite,parentPos);

				//Update parent nodes as they have probably changed
				//current node position*change of sprite size
				parts[i].parentNode = new Vector2(parts[i].parentNode.x*parentDim.x/parts[i].sprite.width,
				                                  parts[i].parentNode.y*parentDim.y/parts[i].sprite.height);
			}
			//add the child nodes so that children parts can be placed in the correct locations
			//use the data from the largest of the parts to prevent overcrowding
			if(currentParts[i].Count > 0)
			{
				foreach(Vector3 node in currentParts[i][0].childrenNodes)
				{
					parts[i].childrenNodes.Add(node);
				}
			}
			else Debug.Log("if " + i + " isn't a tail... there is a problem...");
		}

		//create new texture for the finalCreation
		finalCreature.sprite = new Texture2D (parts[3].sprite.width, parts[3].sprite.height);
		TextureHelper.copy(ref finalCreature.sprite,parts[3].sprite);
		Debug.Log (finalCreature.sprite.width + " " + finalCreature.sprite.height);
		for(int i = currentParts.Count-1; i > 0; i--)
		{
			foreach(Vector3 node in parts[i].childrenNodes)
			{
				Vector2 parentNode = new Vector2((parts[i].sprite.width*node.x)-(parts[i-1].sprite.width*parts[i-1].parentNode.x),
				                                 (parts[i].sprite.height*node.y)-(parts[i-1].sprite.width*parts[i-1].parentNode.x));

				Debug.Log("Part " + i + " is being positioned at " + parentNode);
				finalCreature.sprite = TextureHelper.combineTextures (parts[i].sprite, new Rect (parentNode.x,parentNode.y,parts[i].sprite.width,parts[i].sprite.height),
				                                                      finalCreature.sprite, new Rect (0, 0, finalCreature.sprite.width,finalCreature.sprite.height));
			}
		}*/

		//combine each category into a part to be combined later
		for(int i = 0; i < currentParts.Count; i++)
		{
			//iniitialize the new sprite as the first sprite in the list to be combined
			parts.Add(i, new CreaturePart());
			parts[i].sprite = new Texture2D ((int)currentParts[i][0].sprite.width,(int)currentParts[i][0].sprite.height);
			TextureHelper.Copy (ref parts[i].sprite,currentParts[i][0].sprite);
			TextureScale.Bilinear (parts[i].sprite,(int)(currentParts[i][0].scale*currentParts[i][0].sprite.width),
			                       (int)(currentParts[i][0].scale*currentParts[i][0].sprite.width));
			//set the parent node to be in the same location for positioning everything else
			parts[i].parentNode = currentParts[i][0].parentNode;

			//combine categories into a single part
			for(int j = 1; j < currentParts[i].Count; j++)
			{
				//Create a holder for the position information
				Vector2 partDim = new Vector2(parts[i].sprite.width,parts[i].sprite.height);

				Texture2D sprite = currentParts[i][j].sprite;
				Vector2 spriteDim = new Vector2(currentParts[i][j].sprite.width*currentParts[i][j].scale,
				                                currentParts[i][j].sprite.height*currentParts[i][j].scale);
				//set the position of the sprite such that all of the objects line up with the parent Node
				Vector2 spritePos = new Vector2((partDim.x*parts[i].parentNode.x)-(spriteDim.x*parts[i].parentNode.x),
				                                (partDim.y*parts[i].parentNode.y)-(spriteDim.y*parts[i].parentNode.y));
				Rect spriteRect = new Rect(spritePos.x,spritePos.y,spriteDim.x,spriteDim.y);

				parts[i].sprite = TextureHelper.CombineTextures(sprite,spriteRect,parts[i].sprite, 
				                                                new Rect(0,0,parts[i].sprite.width,parts[i].sprite.height));

				parts[i].parentNode = new Vector2(parts[i].sprite.width/partDim.x * parts[i].parentNode.x,
				                                  parts[i].sprite.height/partDim.y * parts[i].parentNode.y);
			}
		}

		//initialize finalCreature as a first part
		finalCreature.sprite = new Texture2D (parts[0].sprite.width, parts[0].sprite.height);
		TextureHelper.Copy (ref finalCreature.sprite,parts[0].sprite);
		//combine each category together
		for(int i = 1; i < parts.Count;i++)
		{
			Vector2 finalSize = new Vector2(finalCreature.sprite.width,finalCreature.sprite.height);
			Vector2 spritePos = new Vector2((0.5f*finalSize.x)-(parts[i].sprite.width*parts[i].parentNode.x),
			                                (0.5f*finalSize.y)-(parts[i].sprite.height*parts[i].parentNode.y));
			finalCreature.sprite = TextureHelper.CombineTextures(parts[i].sprite,new Rect(spritePos.x,spritePos.y,parts[i].sprite.width,parts[i].sprite.height),
			                                                     finalCreature.sprite, new Rect(0,0,finalSize.x,finalSize.y));
		}


		//some final cleanup
		parts.Clear ();
		currentParts.Clear ();

		//return the texture
		return finalCreature.sprite;
	}

	private static List<CreaturePart> tempPart(int layer,float[] modifier, ref string[] stringList, ref Dictionary<string,CreaturePart> creatureList)
	{
		//tails are last... obviously
		List<CreaturePart> newParts = new List<CreaturePart> ();
		for(int i = 0; i < stringList.Length; i++)
		{
			if(modifier[i] > 0) 
			{
				CreaturePart newPart = new CreaturePart(creatureList[stringList[i]]);
				newPart.scale = modifier[i];
				newParts.Add(newPart);
			}
		}
		//sort the list largest-smallest
		newParts.Sort (delegate(CreaturePart A, CreaturePart B) 
		               {
						return A.scale.CompareTo (B.scale);
						});
		//currentParts.Add (layer,newParts);
		return newParts;
	}
}