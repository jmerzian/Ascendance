using UnityEngine;
using System;
using System.Threading;
using System.Collections;
using System.Collections.Generic;

public static class TextureHelper
{
	//helper function to copy textures
	public static void Copy(ref Texture2D output, Texture2D source)
	{
		Color[] textureData = source.GetPixels ();
		if(textureData.Length > 0)output.SetPixels (textureData);
		else Debug.Log("No color Data");
	}
	public static void Clear (ref Texture2D texture)
	{
		Color[] pixelData = texture.GetPixels ();
		for(int i = 0; i < pixelData.Length; i++)
		{
			pixelData[i] = new Color(0,0,0,0);
		}
		texture.SetPixels (pixelData);
	}

	public static Texture2D CombineTextures(Texture2D Araw, Rect Apos, Texture2D Braw, Rect Bpos)
	{
		int width;
		int height;

		//TODO make this work with negative numbers
		if(Apos.x < 0 || Bpos.x < 0 || Apos.y < 0 || Bpos.y < 0) Debug.Log("negative value cannot combine properly");
		if (Apos.x < Bpos.x)
		{
			if ((Bpos.x-Apos.x) + Bpos.width > Apos.width)width = (int)(Bpos.x + Bpos.width);
			else width = (int)(Math.Abs(Apos.x)+Apos.width);
		}
		else
		{
			if ((Apos.x-Bpos.x) + Apos.width > Bpos.width)width = (int)(Apos.x + Apos.width);
			else width = (int)(Math.Abs(Bpos.x)+Bpos.width);
		}

		if (Apos.y < Bpos.y)
		{
			if ((Bpos.y-Apos.y) + Bpos.height > Apos.height)height = (int)(Bpos.y + Bpos.height);
			else height = (int)(Math.Abs(Apos.y)+Apos.height);
		}
		else
		{
			if ((Apos.y-Bpos.y) + Apos.height > Bpos.height)height = (int)(Apos.y + Apos.height);
			else height = (int)(Math.Abs(Bpos.y)+Bpos.height);
		}
		
		Texture2D finalTexture = new Texture2D(width,height);
		Color nothing = new Color(0,0,0,0);
		
		//create new texture to prevent altering the original
		Texture2D A = new Texture2D (Araw.width,Araw.height);
		//copy the data to the new texture
		TextureHelper.Copy (ref A, Araw);
		//scale the image to the right dimensions
		TextureScale.Bilinear (A, (int)Apos.width, (int)Apos.height);
		//rinse and repeat
		Texture2D B = new Texture2D (Braw.width,Braw.height);
		TextureHelper.Copy (ref B, Braw);
		TextureScale.Bilinear (B, (int)Bpos.width, (int)Bpos.height);
		
		int debugA = 0;
		int debugB = 0;
		int debugAB = 0;
		int debugX = 0;
		bool aFrame = false;
		bool bFrame = false;
		
		//TODO ugly, find a better way
		for(int x = 0; x < width; x++)
		{
			for(int y = 0; y <height; y ++)
			{
				//within the A reference frame in the X direction
				if(Apos.x < x && x < (Apos.x+Apos.width))
				{
					if(Apos.y < y && y < (Apos.y+Apos.height)) aFrame = true;
					else aFrame = false;
				}
				if(Bpos.x < x && x < (Bpos.x+Bpos.width))
				{
					if(Bpos.y < y &&  y < (Bpos.y+Bpos.height)) bFrame = true;
					else bFrame = false;
				}

				if(aFrame && bFrame)
				{
					finalTexture.SetPixel(x,y, combineColors(A.GetPixel((int)(x-Apos.x),(int)(y-Apos.y)),B.GetPixel((int)(x-Bpos.x),(int)(y-Bpos.y))));
					debugAB++;
				}
				else if(aFrame && !bFrame) 
				{
					finalTexture.SetPixel(x,y,A.GetPixel((int)(x-Apos.x),(int)(y-Apos.y))); 
					debugA++;
				}
				else if(!aFrame && bFrame)
				{
					finalTexture.SetPixel(x,y,B.GetPixel((int)(x-Bpos.x),(int)(y-Bpos.y))); 
					debugB++;
				}
				else 
				{
					finalTexture.SetPixel(x,y,nothing);
					debugX++;
				}
			}
		}
		//Turn colors back into texture
		finalTexture.Apply ();
		
		return finalTexture;
	}
	private static Color combineColors(Color A, Color B)
	{
		if(A.a > 0)
		{
			if(B.a>0)
			{
				//TODO decide whether to mix or overlay, currently overlay
				if(A.a > B.a) return A;
				else if(B.a > A.a) return B;
				else return A;
			}
			else return A;
		}
		else if(B.a > 0)
		{
			return B;
		}
		else return new Color(0,0,0,0);
	}
}

public class TextureScale
{
	public class ThreadData
	{
		public int start;
		public int end;
		public ThreadData (int s, int e) {
			start = s;
			end = e;
		}
	}
	
	private static Color[] texColors;
	private static Color[] newColors;
	private static int w;
	private static float ratioX;
	private static float ratioY;
	private static int w2;
	private static int finishCount;
	private static Mutex mutex;
	
	public static void Point (Texture2D tex, int newWidth, int newHeight)
	{
		ThreadedScale (tex, newWidth, newHeight, false);
	}
	
	public static void Bilinear (Texture2D tex, int newWidth, int newHeight)
	{
		ThreadedScale (tex, newWidth, newHeight, true);
	}
	
	private static void ThreadedScale (Texture2D tex, int newWidth, int newHeight, bool useBilinear)
	{
		texColors = tex.GetPixels();
		newColors = new Color[newWidth * newHeight];
		if (useBilinear)
		{
			ratioX = 1.0f / ((float)newWidth / (tex.width-1));
			ratioY = 1.0f / ((float)newHeight / (tex.height-1));
		}
		else {
			ratioX = ((float)tex.width) / newWidth;
			ratioY = ((float)tex.height) / newHeight;
		}
		w = tex.width;
		w2 = newWidth;
		var cores = Mathf.Min(SystemInfo.processorCount, newHeight);
		var slice = newHeight/cores;
		
		finishCount = 0;
		if (mutex == null) {
			mutex = new Mutex(false);
		}
		if (cores > 1)
		{
			int i = 0;
			ThreadData threadData;
			for (i = 0; i < cores-1; i++) {
				threadData = new ThreadData(slice * i, slice * (i + 1));
				ParameterizedThreadStart ts = useBilinear ? new ParameterizedThreadStart(BilinearScale) : new ParameterizedThreadStart(PointScale);
				Thread thread = new Thread(ts);
				thread.Start(threadData);
			}
			threadData = new ThreadData(slice*i, newHeight);
			if (useBilinear)
			{
				BilinearScale(threadData);
			}
			else
			{
				PointScale(threadData);
			}
			while (finishCount < cores)
			{
				Thread.Sleep(1);
			}
		}
		else
		{
			ThreadData threadData = new ThreadData(0, newHeight);
			if (useBilinear)
			{
				BilinearScale(threadData);
			}
			else
			{
				PointScale(threadData);
			}
		}
		
		tex.Resize(newWidth, newHeight);
		tex.SetPixels(newColors);
		tex.Apply();
	}
	
	public static void BilinearScale (System.Object obj)
	{
		ThreadData threadData = (ThreadData) obj;
		for (var y = threadData.start; y < threadData.end; y++)
		{
			int yFloor = (int)Mathf.Floor(y * ratioY);
			var y1 = yFloor * w;
			var y2 = (yFloor+1) * w;
			var yw = y * w2;
			
			for (var x = 0; x < w2; x++) {
				int xFloor = (int)Mathf.Floor(x * ratioX);
				var xLerp = x * ratioX-xFloor;
				newColors[yw + x] = ColorLerpUnclamped(ColorLerpUnclamped(texColors[y1 + xFloor], texColors[y1 + xFloor+1], xLerp),
				                                       ColorLerpUnclamped(texColors[y2 + xFloor], texColors[y2 + xFloor+1], xLerp),
				                                       y*ratioY-yFloor);
			}
		}
		
		mutex.WaitOne();
		finishCount++;
		mutex.ReleaseMutex();
	}
	
	public static void PointScale (System.Object obj)
	{
		ThreadData threadData = (ThreadData) obj;
		for (var y = threadData.start; y < threadData.end; y++)
		{
			var thisY = (int)(ratioY * y) * w;
			var yw = y * w2;
			for (var x = 0; x < w2; x++) {
				newColors[yw + x] = texColors[(int)(thisY + ratioX*x)];
			}
		}
		
		mutex.WaitOne();
		finishCount++;
		mutex.ReleaseMutex();
	}
	
	private static Color ColorLerpUnclamped (Color c1, Color c2, float value)
	{
		return new Color (c1.r + (c2.r - c1.r)*value, 
		                  c1.g + (c2.g - c1.g)*value, 
		                  c1.b + (c2.b - c1.b)*value, 
		                  c1.a + (c2.a - c1.a)*value);
	}
}