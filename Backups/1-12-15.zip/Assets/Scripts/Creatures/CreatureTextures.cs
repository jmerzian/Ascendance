using UnityEngine;
using System.Collections.Generic;

public class CreatureTextures:MonoBehaviour
{
	//images taken from inspector
	public List<CreaturePart> bacteriaMouths;
	public List<CreaturePart> bacteriaHeads;
	public List<CreaturePart> bacteriaBodies;
	public List<CreaturePart> bacteriaTails;

	void Start()
	{
		//TODO find a use for heads
		for(int i = 0; i < BacteriaStrings.nutrientTypes.Length; i++)
		{
			BacteriaRender.mouths.Add(BacteriaStrings.nutrientTypes[i],bacteriaMouths[i]);
		}
		for(int i = 0; i < BacteriaStrings.senseTypes.Length; i++)
		{
			BacteriaRender.heads.Add(BacteriaStrings.senseTypes[i],bacteriaHeads[i]);
		}
		for(int i = 0; i < BacteriaStrings.energyTypes.Length; i++)
		{
			BacteriaRender.bodies.Add(BacteriaStrings.energyTypes[i],bacteriaBodies[i]);
		}
		for(int i = 0; i < BacteriaStrings.movementTypes.Length; i++)
		{
			BacteriaRender.tails.Add(BacteriaStrings.movementTypes[i],bacteriaTails[i]);
		}
	}
}