using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Resources
{
	public class BiomeResources
	{
		public Dictionary<string,float> mineralQuantities = new Dictionary<string,float>();

		public BiomeResources()
		{
			foreach(string mineral in Control.minerals)
			{
				if(!mineralQuantities.ContainsKey(mineral))
				{
					mineralQuantities.Add(mineral,0);
				}
			}
		}

		public BiomeResources(float[] newMinerals) : this()
		{
			for(int i = 0; i < newMinerals.Length; i ++)
			{
				mineralQuantities[Control.minerals[i]] = newMinerals[i];
			}
		}
		
		public BiomeResources(Dictionary<string,float> newMinerals) : this()
		{
			foreach(KeyValuePair<string,float> mineral in newMinerals)
			{
				if(Control.minerals.Contains(mineral.Key)) mineralQuantities[mineral.Key] = mineral.Value;
				else Debug.Log("mineral doesn't exist... ");
			}
		}
	}
	
	public class PlanetResources
	{
		public Dictionary<string,float> gasQuantities = new Dictionary<string,float>();

		//calculated from other variables
		private bool atmosphere;
		private float gasWeight;
		private float pressure;

		public PlanetResources()
		{
			foreach(string gas in Control.gasses)
			{
				//if a gas hasn't been initialized initiliaze it as zero
				if(!gasQuantities.ContainsKey(gas))
				{
					gasQuantities.Add(gas,0);
				}
			}
		}

		public PlanetResources(float[] newGasses) : this()
		{
			int iterations = 0;
			if(newGasses.Length < Control.gasses.Count)iterations = newGasses.Length;
			else iterations = Control.gasses.Count;

			for(int i = 0; i < iterations; i ++)
			{
				gasQuantities[Control.gasses[i]] = newGasses[i];
			}
		}

		public PlanetResources(Dictionary<string,float> newGasses) : this()
		{
			if(newGasses.Count < Control.gasses.Count)
			{
				foreach(KeyValuePair<string,float> gas in newGasses)
				{
					if(Control.gasses.Contains(gas.Key)) gasQuantities[gas.Key] = gas.Value;
					else Debug.Log("Gas doesn't exist... ");
				}
			}
			else
			{
				foreach(string gas in Control.gasses)
				{
					if(newGasses.ContainsKey(gas)) gasQuantities[gas] = newGasses[gas];
					else Debug.Log("Input contains unlisted gas... ");
				}
			}
		}

		//if anything in the gasses has
		public bool hasAtmosphere()
		{
			getPressure (1);

			if(gasWeight > 0) atmosphere = true;
			else atmosphere = false;

			return atmosphere;
		}

		public float getPressure(float radius)
		{
			gasWeight = 0;
			foreach(string gas in Control.gasses)
			{
				gasWeight += Control.gasWeights[Control.gasses.IndexOf(gas)]*gasQuantities[gas];
			}
			pressure = gasWeight / (200 * 3.1415f * radius);
			return pressure;
		}
	}
}