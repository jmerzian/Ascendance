﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Ascendance;
using Resources;

public class Planet : MonoBehaviour
{
	/*********************************************************************************
	 * variables describing the planet
	 * ******************************************************************************/
	public GameObject DefaultBiome;
	public Transform Parent;
	public float Radius;
	public float Orbit;
	public int startAngle;
	public float OrbitSpeed;
	public Sprite Unexplored;
	public Sprite Explored;
	public bool explored;
	public PlanetResources resources;
	//make resources addable from the main unity window
	public float[] newResources;

	/*****************************************************************************
	 * Hold information about the biomes and creatures living on them
	 * **************************************************************************/
	private Dictionary<Transform,Biome> planetBiomes = new Dictionary<Transform,Biome>();
	private Dictionary<Biome,Dictionary<string,BacteriaSpecies>> biomeBacteria = new Dictionary<Biome,Dictionary<string,BacteriaSpecies>> ();
	private Dictionary<string,BacteriaSpecies> planetBacteria = new Dictionary<string,BacteriaSpecies> ();

	//interactivity functions
	private bool hasBeenRevealed = false;

	/***********************************************************
	 * Initialize planet to be at x position, and set up biomes
	 * *********************************************************/
	public virtual void Start () 
	{
		//Adjust self to the proper size
		transform.localScale = new Vector3 (Radius, Radius);
		//Place in the proper orbit
		transform.position = new Vector3 (Parent.position.x+Orbit*Mathf.Cos(startAngle), Parent.position.y+Orbit*Mathf.Sin(startAngle), 0);
		//Place Blank Biomes
		int biomeSpaces = (int)Mathf.Ceil(Radius*100);
		for(int i = 0; i < biomeSpaces; i++)
		{
			//maths out the angle and positions of the new biomes
			float angle = (2*Mathf.PI*i)/biomeSpaces;
			Vector3 BiomePosition = new Vector3((Mathf.Cos(angle)*Radius*5)+transform.position.x,(Mathf.Sin(angle)*Radius*5)+transform.position.y,0);

			//Create new biome and add it to the ist of biomes on this planet
			GameObject newBiome = Instantiate(DefaultBiome,BiomePosition,transform.rotation) as GameObject;

			//Scale to make biomes identical sizes
			float scale = transform.lossyScale.x*2;
			float parentScale = transform.parent.lossyScale.x;

			//position rotate, parent and color
			newBiome.transform.parent = transform;
			newBiome.transform.localScale = new Vector3(parentScale/scale,parentScale/scale);
			newBiome.transform.rotation = Quaternion.AngleAxis((angle*180/Mathf.PI)-90, Vector3.forward);

			//Name the object the same as the planet name and tag as biome
			newBiome.transform.tag = "Biome";
			newBiome.transform.name = transform.name + "Biome";

			//add to list of biomes for update etc.
			planetBiomes.Add(newBiome.transform,new Biome(DefaultBiome.name,this));
		}
		//add atmosphere
		resources = new PlanetResources(newResources);
	}

	/************************************************************
	 * Check to see if planet has been explored and manage biomes
	 * *********************************************************/
	public virtual void Update () 
	{
		//Move planet in orbit around parent body
		transform.RotateAround(Parent.position, Vector3.forward,OrbitSpeed*Time.deltaTime);
		//Vector3 newPosition = (transform.position - Parent.position).normalized * Radius + Parent.position;
		//transform.position = Vector3.Slerp(transform.position, newPosition, Time.deltaTime * OrbitCorrection);
		if(explored && !hasBeenRevealed)
		{
			transform.GetComponent<SpriteRenderer>().sprite = Explored;
			transform.collider2D.enabled = true;
			foreach(KeyValuePair<Transform, Biome> unknownBiome in planetBiomes)
			{
				unknownBiome.Key.renderer.enabled = true;
				unknownBiome.Key.collider2D.enabled = true;
			}
		}
	}

	/********************************************************************8
	 * Add life to biome
	 * ************************************************************************/
	public void addBacteria(Transform biomeSquare)
	{
		string[] bacteriaNames = new string[]{"test","OMNOM","something something","FUCK","otherTest"};
		int random = (int)Random.Range(0,bacteriaNames.Length);
		Debug.Log (random);
		Bacteria newBacteria = new Bacteria (bacteriaNames[random], new float[]{1,0,0,0}, new float[]{1,0,0}, new float[]{1,0,0});
		AddLife.addBacteria (newBacteria,planetBiomes[biomeSquare],10);
	}

	/******************************************************************8
	 * Allow access to information stored within this class
	 * **************************************************************/
	//return information about biomes
	public Dictionary<Transform,Biome> GetPlanetBiomes()
	{
		return planetBiomes;
	}

	//return information about bacterium
	public Dictionary<string,BacteriaSpecies> GetPlanetBacteria()
	{
		return planetBacteria;
	}
	
	public Dictionary<string,BacteriaSpecies> GetBiomeBacteria(Biome biome)
	{
		if(biomeBacteria.ContainsKey(biome)) return biomeBacteria[biome];
		else return null;
	}

	//if its unique ot the planet make a seperate definition otherwise update numbers
	private void addUniqueBacteria(Bacteria bacteria, int quantity)
	{
		bool unique = false;

		if(planetBacteria.Count < 1) unique = true;
		if(!planetBacteria.ContainsKey(bacteria.name)) unique = true;
		if(unique) planetBacteria.Add(bacteria.name, new BacteriaSpecies(bacteria,quantity));
		else planetBacteria[bacteria.name].quantity += quantity;
	}

	//Add new bacteria to the global database
	public void AddPlanetBacteria(Biome biome, Bacteria bacteria, int quantity)
	{
		if(!biomeBacteria.ContainsKey(biome))
		{
			if(planetBiomes.ContainsValue(biome)) 
			{
				biomeBacteria.Add(biome, new Dictionary<string,BacteriaSpecies>(){{bacteria.name,new BacteriaSpecies(bacteria,quantity)}});
				addUniqueBacteria(bacteria,quantity);
			}
			else Debug.Log("Trying to add biomes to the wrong planets check parenting...");
		}
		else
		{
			if(!biomeBacteria[biome].ContainsKey(bacteria.name))biomeBacteria[biome].Add(bacteria.name,new BacteriaSpecies(bacteria,quantity));
			addUniqueBacteria(bacteria,quantity);
		}
	}
}
