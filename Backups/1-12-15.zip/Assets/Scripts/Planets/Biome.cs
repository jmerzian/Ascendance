using UnityEngine;
using System.Collections.Generic;
using Resources;

namespace Ascendance
{
	public class Biome
	{
		//basic information about biome
		public string name;
		public bool selected;
		public BiomeResources resources = new BiomeResources();

		//parent planet
		Planet parent;

		//list of animals present on biome
		private Dictionary<Bacteria,int> bacteria = new Dictionary<Bacteria,int>();

		public Biome(string Name, Planet parentPlanet)
		{
			name = Name;
			parent = parentPlanet;

			foreach(string mineral in Control.minerals)
			{
				resources.mineralQuantities[mineral] = 10;
			}
		}

		public void AddBacteria(Bacteria newBacteria, int quantity)
		{
			if(!bacteria.ContainsKey(newBacteria))bacteria.Add (newBacteria,quantity);
			else bacteria[newBacteria] += quantity;
			if(parent.GetBiomeBacteria(this) != null)
			{
				if(!parent.GetBiomeBacteria(this).ContainsKey(newBacteria.name)) parent.AddPlanetBacteria(this,newBacteria,quantity);
			}
			else parent.AddPlanetBacteria(this,newBacteria,quantity);
		}

		public Dictionary<Bacteria,int> GetBacteriaList()
		{
			return bacteria;
		}
	}
}