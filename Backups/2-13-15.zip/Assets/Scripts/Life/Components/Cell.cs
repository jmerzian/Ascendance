using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class Cell
{
	//image of the cell
	public Texture2D sprite;

	//type of cell and unique name
	public string name;
	public string type;

	//amount of material this cell can store
	public float storageSize;

	/*********************************************
	 * resource consumption and creation
	 * ********************************************/
	//amount of resource available in this cell
	public Dictionary<string, float> stored = new Dictionary<string, float>();
	
	//amount of resource being used
	public Dictionary<string, float> resourceIn = new Dictionary<string, float>();
	//amount of resource being output
	public Dictionary<string, float> resourceOut = new Dictionary<string, float>();

	//amount of energy being used
	public Dictionary<string, float> energyIn = new Dictionary<string, float>();
	//amount of energy being output
	public Dictionary<string, float> energyOut = new Dictionary<string, float>();

	//resources needed for life
	public float minimumToLive;

	//Check if the cell has already been updated this turn
	public bool updated;

	public Cell()
	{
		//create a new empty sprite to hold the Cell's sprite
		sprite = new Texture2D (320, 320);

		//denotates a holder cell
		type = null;

		//initialize all the materials
		foreach(string gas in Control.gasses)
		{
			stored.Add(gas,0);
			resourceIn.Add(gas,0);
			resourceOut.Add(gas,0);
		}
		foreach(string mineral in Control.minerals)
		{
			stored.Add(mineral,0);
			resourceIn.Add(mineral,0);
			resourceOut.Add(mineral,0);
		}
		foreach(string organic in Control.organics)
		{
			stored.Add(organic,0);
			resourceIn.Add(organic,0);
			resourceOut.Add(organic,0);
		}
		foreach(string energy in Control.energies)
		{
			stored.Add(energy,0);
			energyIn.Add(energy,0);
			energyOut.Add(energy,0);
		}
		//Life is weird and is automatically one... always
		energyOut ["Life"] = 1;
	}

	public Cell(Cell copy): this()
	{
		//TODO test to see fi I need to somehow duplicate this class
		name = copy.name;

		sprite = copy.sprite;

		type = copy.type;

		storageSize = copy.storageSize;

		stored = new Dictionary<string,float> (copy.stored);
		resourceIn = new Dictionary<string,float> (copy.resourceIn);
		resourceOut = new Dictionary<string,float> (copy.resourceOut);

		energyIn = new Dictionary<string,float> (copy.energyIn);
		energyOut = new Dictionary<string,float> (copy.energyOut);
	}
}