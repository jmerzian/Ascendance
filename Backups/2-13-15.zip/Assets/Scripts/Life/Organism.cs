using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Organism
{
	//image of the Bacteria
	public Texture2D sprite;

	//name
	public string genus;
	public string species;

	public Dictionary<string, float> resourceIn = new Dictionary<string, float>();
	public Dictionary<string, float> resourceOut = new Dictionary<string, float>();

	public Dictionary<string, float> energyIn = new Dictionary<string, float>();
	public Dictionary<string, float> energyOut = new Dictionary<string, float>();

	//resources needed for life
	public float minimumToLive;

	public Organism()
	{
		//create a new empty sprite to hold the Cell's sprite
		sprite = new Texture2D (320, 320);
		
		//initialize all the materials
		foreach(string gas in Control.gasses)
		{
			resourceIn.Add(gas,0);
			resourceOut.Add(gas,0);
		}
		foreach(string mineral in Control.minerals)
		{
			resourceIn.Add(mineral,0);
			resourceOut.Add(mineral,0);
		}
		foreach(string organic in Control.organics)
		{
			resourceIn.Add(organic,0);
			resourceOut.Add(organic,0);
		}
		foreach(string energy in Control.energies)
		{
			energyIn.Add(energy,0);
			energyOut.Add(energy,0);
		}
	}
}