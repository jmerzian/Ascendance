using UnityEngine;
using System;
using System.Collections;
using System.Collections.Generic;

public class Bacteria: Organism
{
	public Cell[,] cellBody = new Cell[10,10];
	public Cell[,] previousBody = new Cell[10,10];
	public bool[,] cellChanged = new bool[10,10];
	
	public Bacteria()
	{
	}

	public Bacteria(Cell[,] bacteria)
	{
		cellBody = bacteria;
	}

	public void Simulate(BiomeResources mineral,PlanetResources gas, EnergyResources energies)
	{	
	}

	/***********************************************
	 * Update the values of the new cell
	 * ***********************************************/
	public void UpdateCell(int x, int y, Cell newCell)
	{
		Vector2[] directions = new Vector2[9]
		{	new Vector2(0,0),
			new Vector2(1,1),
			new Vector2(1,0),
			new Vector2(0,1),
			new Vector2(-1,-1),
			new Vector2(0,-1),
			new Vector2(-1,0),
			new Vector2(1,-1),
			new Vector2(-1,1)
		};	

		Array.Copy (cellBody,0,previousBody,0,cellBody.Length);
		
		cellBody [x, y] = new Cell (newCell);
		//set the flag that this cell has already recieved an update
		cellBody [x, y].updated = true;

		if (previousBody [x, y] == null) previousBody [x, y] = new Cell ();

		//Reset the cell's stored values to what was previously in the cell
		foreach(KeyValuePair<string,float> resource in previousBody[x,y].stored)
		{
			cellBody[x,y].stored[resource.Key] = resource.Value;
		}

		/*
		//scale the resource inputs and outputs 
		foreach(KeyValuePair<string,float> resource in previousBody[x,y].resourceIn)
		{
			if(cellBody[x,y].resourceIn[resource.Key]>0)
			{
				foreach(KeyValuePair<string,float> energy in previousBody[x,y].energyIn)
				{
					string output = Recipes.recipes[energy.Key].getResult(resource.Key);
					Debug.Log(output);
					if(cellBody[x,y].energyIn[energy.Key] > 0 && output != null)
					{
						if(cellBody[x,y].stored[output] > 0)
						{
							Debug.Log(cellBody[x,y].stored[resource.Key] + resource.Key);
							cellBody[x,y].resourceIn[resource.Key] = cellBody[x,y].stored[resource.Key] + previousBody[x,y].resourceIn[resource.Key];
							if(!Control.energies.Contains(output))cellBody[x,y].resourceOut[output] =
								cellBody[x,y].resourceIn[resource.Key] * energy.Value;
							else cellBody[x,y].energyOut[output] =
								cellBody[x,y].resourceIn[resource.Key] * energy.Value;
						}
					}
				}
			}
		}*/
		
		//for all possibly effected cells
		foreach(Vector2 dir in directions)
		{
			int dirx = x+(int)dir.x;
			int diry = y+(int)dir.y;
			if(dirx >= 0 && dirx < 10 && diry >= 0 && diry < 10)
			{
				//check all resources in use
				foreach(KeyValuePair<string,float> resource in newCell.resourceIn)
				{
					/************************************************************************************
					 * Set The adjacent Cells to appropriate values for each different type of cell
					 * ****************************************************************************/
					//if the location doesn't contain a cell create a blank one
					if(cellBody[dirx,diry] == null) 
						cellBody[dirx,diry] = new Cell();
					if(previousBody[dirx,diry] == null) 
						previousBody[dirx,diry] = new Cell();
					/********************************************
					 * Producer
					 * ***************************************/
					if(newCell.type == "Producer" || previousBody[x,y].type == "Producer")
					{
						//get the resource produced efficiency
						float output = cellBody[x,y].resourceOut[resource.Key] - previousBody[x,y].resourceOut[resource.Key];
						//subtract the amount used efficiency
						output -= cellBody[x,y].resourceIn[resource.Key] - previousBody[x,y].resourceIn[resource.Key];
						//TODO multiply that by the amount of resource available in this square
						
						//Debug.Log("Cell " + new Vector2(dirx,diry) + " has " + resource.Key + " net of " + output);
						cellBody[dirx,diry].stored[resource.Key] += output;
					}
					/******************************************
					 * Transport
					 * ****************************************/
					//TODO make the transport cells actually do something
					if(newCell.type == "Transport" || previousBody[x,y].type == "Transport")
					{
					}
					
					/****************************************
					 * null
					 * ***************************************/
					//if a cell is being removed re-calculate for what used to be in that location
					if(newCell.type == null)
					{
					}
				}

				//TODO start the mass updating again
				if(!cellBody[dirx,diry].updated && cellBody[dirx,diry].type != null)
				{
					//Debug.Log("Updating :"+new Vector2(dirx,diry));
					UpdateCell(dirx,diry,cellBody[dirx,diry]);
				}
			}
		}
	}
	
	
	public void Render()
	{
		Vector2[] directions = new Vector2[8]
		{
			new Vector2(1,1),
			new Vector2(1,0),
			new Vector2(0,1),
			new Vector2(-1,-1),
			new Vector2(0,-1),
			new Vector2(-1,0),
			new Vector2(1,-1),
			new Vector2(-1,1)
		};	

		Texture2D newSprite = new Texture2D(320,320);
		Texture2D smallTransparent = new Texture2D (32, 32);
		smallTransparent.SetPixels (TextureHelper.newImage (32, 32, new Color(0,0,0,0)));
		smallTransparent.Apply ();

		Texture2D[,] resizedCell = new Texture2D[10, 10];
		Texture2D[,] cellShader = new Texture2D[10, 10];
		Texture2D[,] cellConnect = new Texture2D[10, 10];

		TextureHelper.Copy (ref newSprite, CellTextures.transparent);
		/*******************************************************************************************
		 * Copy the data from all of the cells and put it into an array that will be further manipulated
		 * ******************************************************************************************/
		for(int x = 0; x < 10; x++)
		{
			for(int y = 0; y < 10; y++)
			{
				if(cellBody[x,y] != null)
				{
					if(cellBody[x,y].type != null)
					{
						resizedCell[x,y] = new Texture2D(320,320);
						TextureHelper.Copy(ref resizedCell[x,y],cellBody[x,y].sprite);
						TextureScale.Point(resizedCell[x,y],32,32);
						//TODO look at all of the adjacent cells to determine how to edit the cell. 

						resizedCell[x,y].Apply();

						//initialize the shader
						cellShader[x,y] = new Texture2D(32,32);
						TextureHelper.Copy(ref cellShader[x,y],CellTextures.center);

						//initialize the interconnect
						cellConnect[x,y] = new Texture2D(32,32);
						TextureHelper.Copy(ref cellConnect[x,y],CellTextures.center);

						foreach(Vector2 dir in directions)
						{
							int dirx = x + (int)dir.x;
							int diry = y + (int)dir.y;
							//check if the neighbor is an edge or a corner
							//if either direction is 0 its an edge
							//Make sure that it is within the grid
							if(dirx >= 0 && dirx < 10 && diry >= 0 && diry < 10)
							{
								if((int)dir.x == 0 || (int)dir.y == 0)
								{
									//make sure a valid cell exists in that location
									if(cellBody[dirx,diry] != null)
									{
										//if it's the same cell combine the filters
										if(cellBody[x,y].name == cellBody[dirx,diry].name)
										{
											Debug.Log("edge found");
											TextureHelper.Copy(ref cellShader[x,y],TextureHelper.CombineTextures(
												cellShader[x,y],TextureHelper.rotate(CellTextures.edge,dir)));
										}
										//if it's a null cell add the next shader
										else if(cellBody[dirx,diry].type == null)
										{
											//Debug.Log("Blank edge found");
											TextureHelper.Copy(ref cellConnect[x,y],TextureHelper.CombineTextures(
												cellShader[x,y],TextureHelper.rotate(CellTextures.edge,dir)));
										}
									}
									else
									{
										//Debug.Log("Blank edge found");
										TextureHelper.Copy(ref cellConnect[x,y],TextureHelper.CombineTextures(
													cellShader[x,y],TextureHelper.rotate(CellTextures.edge,dir)));
									}
								}
								//otherwise its a corner
								else
								{
									//make sure a valid cell exists in that location
									if(cellBody[dirx,diry] != null)
									{
										//if it's the same cell combine the filters
										if(cellBody[x,y].name == cellBody[dirx,diry].name)
										{
											//Debug.Log("corner found");
											TextureHelper.Copy(ref cellShader[x,y],TextureHelper.CombineTextures(
												cellShader[x,y],TextureHelper.rotate(CellTextures.corner,dir)));
										}
										//if it's a null cell add the next shader
										else if(cellBody[dirx,diry].type == null)
										{
											//Debug.Log("Blank corner found");
											TextureHelper.Copy(ref cellConnect[x,y],TextureHelper.CombineTextures(
												cellShader[x,y],TextureHelper.rotate(CellTextures.corner,dir)));
										}
									}
									else
									{
										//Debug.Log("Blank corner found");
										TextureHelper.Copy(ref cellConnect[x,y],TextureHelper.CombineTextures(
											cellShader[x,y],TextureHelper.rotate(CellTextures.corner,dir)));
									}
								}
								//apply the shaders
								cellShader[x,y].Apply();
								cellConnect[x,y].Apply();
							}
						}

						//Combing the interconnect with the 
						//TODO maybe split this up...
						//TextureHelper.Copy(ref cellConnect[x,y],TextureHelper.CombineTextures(
							//CellTextures.interconnect,smallTransparent,cellConnect[x,y]));

						TextureHelper.Copy(ref cellConnect[x,y],smallTransparent);
						cellConnect[x,y].Apply();

						TextureHelper.Copy(ref resizedCell[x,y],TextureHelper.CombineTextures(
							resizedCell[x,y],cellConnect[x,y],cellShader[x,y]));
						                 
						resizedCell[x,y].Apply();

						for(int xx = 0; xx < 32; xx++)
						{
							for(int yy = 0; yy < 32; yy++)
							{
								newSprite.SetPixel((32*x)+xx,320-((32*y)+yy),resizedCell[x,y].GetPixel(xx,yy));
							}
						}
					}
				}
			}
		}

		newSprite.Apply ();
		TextureHelper.Copy (ref sprite, newSprite);
	}

	public void Evolve()
	{
	}
}