﻿using UnityEngine;
using System.Collections;
using GUI;

public class CameraMotion : MonoBehaviour 
{
	//maximum viewport scalings
	public float sizeMin;
	public float sizeMax;

	//Camera Focus
	public Transform focusObject;
	private float planetPos;
	public float camSpeed;

	//Object Selection Variables
	private bool click = false;
	private float delay =  0.25f;
	private float doubleClickTime;
	private Transform SelectedObject = null;
	public Transform PlanetSelector;
	public Transform BiomeSelector;

	// Update is called once per frame
	void Update () 
	{		
		/*******************************************
		 * Check to see if an object is being selected
		 * *******************************************/
		//this is how long in seconds to allow for a double click
		if (Input.GetMouseButtonDown (0)) 
		{
			if (!click) 
			{ // first click no previous clicks
				click = true;
				doubleClickTime = Time.time; // save the current time
				SelectedObject = ObjectSelection();
			} 
			else 
			{
				click = false; // found a double click, now reset
				if(SelectedObject != null)
				{
					if(SelectedObject == ObjectSelection())
					{
						if(SelectedObject.tag == "Planet") focusObject = SelectedObject;
					}
					else
					{
						click = true;
					}
				}
			}
		}
		if (click) 
		{
			// if the time now is delay seconds more than when the first click started. 
			if ((Time.time - doubleClickTime) > delay) 
			{
				//basically if thats true its been too long and we want to reset so the next click is simply a single click and not a double click.
				click = false;
			}
		}
		//deselect all selected objects
		if(Input.GetMouseButtonDown(1))
		{
			SelectedObject = null;
		}
		/***************************************************************
		 * If an object has been selected position the selector and/or the camera on the selected object
		 * ***********************************************************/

		//Select and deselect planet
		if(SelectedObject != null && SelectedObject.tag == "Planet")
		{
			PlanetSelector.transform.renderer.enabled = true;
			PlanetSelector.position = SelectedObject.position;
			PlanetSelector.localScale = SelectedObject.lossyScale;
		}
		else
		{
			PlanetSelector.transform.renderer.enabled = false;
		}
		
		//select and deselect biome
		if(SelectedObject != null && SelectedObject.tag == "Biome")
		{
			BiomeSelector.transform.renderer.enabled = true;
			GUIAction.SelectBiome(SelectedObject);
			BiomeSelector.transform.position = SelectedObject.transform.position;
			BiomeSelector.transform.rotation = SelectedObject.transform.rotation;
			BiomeSelector.transform.localScale = SelectedObject.transform.lossyScale;
		}
		else
		{
			BiomeSelector.transform.renderer.enabled = false;
			GUIAction.SelectBiome(null);
		}

		/*****************************************************************
		 * Zoom the camera in and out and move around a selected planet
		 * ****************************************************************/
		if (Input.GetAxis("Mouse ScrollWheel") > 0) // forward
		{
			Camera.main.orthographicSize--;
		}
		if (Input.GetAxis("Mouse ScrollWheel") < 0) // back
		{
			Camera.main.orthographicSize++;
		}
		if(Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.A))
		{
			planetPos -= camSpeed;
		}
		if(Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.D))
		{
			planetPos += camSpeed;
		}
		
		Camera.main.orthographicSize = Mathf.Clamp(Camera.main.orthographicSize, sizeMin, sizeMax );

		/*****************************************************************
		 * Position and rotate the Camera around the desired planet
		 * *************************************************************/
		if(focusObject != null)
		{
			float PlanetRadius = focusObject.lossyScale.x*5;
			Vector2 PlanetPosition = new Vector2((Mathf.Sin(planetPos)*PlanetRadius), (Mathf.Cos(planetPos)*PlanetRadius));
			transform.position = new Vector3(focusObject.position.x + PlanetPosition.x,focusObject.position.y + PlanetPosition.y,-10);

			transform.rotation = Quaternion.AngleAxis(-planetPos*180/Mathf.PI, Vector3.forward);
		}
	}

	private Transform ObjectSelection()
	{
		RaycastHit2D hit = Physics2D.Raycast(Camera.main.ScreenToWorldPoint(Input.mousePosition), Vector2.zero);
		
		if(hit.collider != null)
		{
			return hit.collider.gameObject.transform;
		}
		return null;
	}
}
