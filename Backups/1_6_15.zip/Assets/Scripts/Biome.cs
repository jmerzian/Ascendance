using UnityEngine;
using System.Collections;

namespace Ascendance
{
	public class Biome
	{
		public bool selected;

		public Biome()
		{
		}
	}
}