using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Ascendance;

namespace GUI
{
	public class GUIDisplay
	{
		public static void PrintBiome(Biome selectedBiome)
		{
		}
	}
	public static class GUIAction
	{
		public static void SelectBiome(Transform selectedBiome)
		{
			if(selectedBiome != null)
			{
				//If valid Biome is selected display information about that biome
				Dictionary<Transform,Biome> planetBiomes = selectedBiome.parent.GetComponent<Planet>().GetPlanetBiomes();
				if(planetBiomes.ContainsKey(selectedBiome))
				{
					GUIDisplay.PrintBiome(planetBiomes[selectedBiome]);
				}
				else
				{
					Debug.LogError("Uncategorized biome... get yo biomes together bro");
				}
			}
			else
			{
				GUIDisplay.PrintBiome(null);
			}
		}
	}
}