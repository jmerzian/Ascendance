using UnityEngine;
using System.Collections;
using Resources;

namespace Ascendance
{
	public class Biome
	{
		public string name;
		public bool selected;
		public BiomeResources resources = new BiomeResources();

		public Biome(string Name)
		{
			name = Name;

			for(int i = 0; i < resources.mineralQuantities.Count; i++)
			{
				resources.mineralQuantities[i] = 10;
			}
		}
	}
}