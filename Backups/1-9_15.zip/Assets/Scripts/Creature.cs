using UnityEngine;
using System.Collections;

public class Creature : MonoBehaviour
{

}