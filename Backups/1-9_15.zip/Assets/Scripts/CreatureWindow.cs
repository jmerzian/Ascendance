using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Ascendance;


public static class CreatureWindow
{
	private static Planet planet;
	private static Biome biome;
	private static List<Creature> informationList = new List<Creature>();

	public static void WindowInformation(int ID, Planet selectedPlanet, Biome selectedBiome)
	{
		planet = selectedPlanet;
		biome = selectedBiome;
		//use ID to switch what list is loaded
		switch(ID)
		{
		case 0:
			break;
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		}
	}
}