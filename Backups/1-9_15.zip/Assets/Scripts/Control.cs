using UnityEngine;
using System.Collections.Generic;

public static class Control
{
	//Time functions
	public static bool paused;

	public static void Pause()
	{
		Time.timeScale = 0;
		paused = true;
	}
	public static void Resume()
	{
		Time.timeScale = 1;
		paused = false;
	}

	//Known and unknown planets
	public static List<Transform> knownPlanets = new List<Transform>();
	//List of all planents by transform, parent
	public static Dictionary<Transform,Transform> allPlanets = new Dictionary<Transform, Transform>();

	private static void ListPLanets()
	{
		foreach(GameObject planet in GameObject.FindGameObjectsWithTag("Planet"))
		{
			if(!allPlanets.ContainsKey(planet.transform))
			{
				if(planet.transform.parent != null) allPlanets.Add(planet.transform, planet.transform.parent);
			}
		}
	}

	public static List<Transform> ChildrenPlanets(Transform parent)
	{
		List<Transform> childList = new List<Transform>();
		foreach(KeyValuePair<Transform,Transform> Planets in allPlanets)
		{
			if(Planets.Value == parent) childList.Add(Planets.Key);
		}
		if (childList.Count > 0)
						return childList;
			else return null;
	}
}