using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public static class ExampleCells
{
	public static Cell[] testCells = new Cell[5];
	public static string[] testCellNames = new string[]{"Clorophyll","Sugar","Muscle","Clorophyll Vein","Sugar Storage"};

	public static void loadCells()
	{
		//Clorophyll
		Cell tempCell = new Cell ();
		tempCell.name = testCellNames [0];
		tempCell.type = "Producer";
		tempCell.energyIn ["Light"] = 1;
		tempCell.resourceIn ["O2"] = 1;
		tempCell.resourceOut ["Clorophyll"] = 1;
		tempCell.minimumToLive = 0.5f;
		tempCell.sprite = CellTextures.textures ["Clorophyll"];
		testCells [0] = new Cell(tempCell);

		//Sugar
		tempCell = new Cell ();
		tempCell.name = testCellNames [1];
		tempCell.type = "Producer";
		tempCell.energyIn ["Life"] = 1;
		tempCell.resourceIn ["Clorophyll"] = 1;
		tempCell.resourceOut ["Sugar"] = 1;
		tempCell.minimumToLive = 0.5f;
		tempCell.sprite = CellTextures.textures ["Sugar"];
		testCells [1] = new Cell(tempCell);

		//Muscle
		tempCell = new Cell ();
		tempCell.name = testCellNames [2];
		tempCell.type = "Producer";
		tempCell.energyIn ["Life"] = 1;
		tempCell.resourceIn ["Sugar"] = 1;
		tempCell.energyOut ["Movement"] = 1;
		tempCell.minimumToLive = 0.5f;
		tempCell.sprite = CellTextures.textures ["Movement"];
		testCells [2] = new Cell(tempCell);

		//Vein
		tempCell = new Cell ();
		tempCell.name = testCellNames [3];
		tempCell.type = "Transport";
		tempCell.storageSize = 1;
		tempCell.resourceIn["Clorophyll"] = 1;
		tempCell.resourceOut ["Clorophyll"] = 0.9f;
		tempCell.minimumToLive = 0.5f;
		tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures ["Transport"],CellTextures.textures ["Clorophyll"],0.5f);
		testCells [3] = new Cell(tempCell);

		//Vein
		tempCell = new Cell ();
		tempCell.name = testCellNames [4];
		tempCell.storageSize = 1;
		tempCell.type = "Transport";
		tempCell.resourceIn["Sugar"] = 1f;
		tempCell.resourceOut ["Sugar"] = 0.9f;
		tempCell.minimumToLive = 0.5f;
		tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures ["Transport"],CellTextures.textures ["Sugar"],0.5f);
		testCells [4] = new Cell(tempCell);
	}
}