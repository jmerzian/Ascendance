using UnityEngine;
using System.Collections.Generic;

public static class Control
{
	/*****************************************************
	 * Types of Resources
	 * TODO use a text file to input these
	 * ***************************************************/
	//Universal resources
	//faith, souls
	public static List<string> universalResourceNames = new List<string>{"Faith","Souls"};
	public static Dictionary<string,float> universalResources = new Dictionary<string,float>(){{"Faith",100},{"Souls",100}};

	//Minerals used in the game
	//water, ammonia, calcium, Iron, Sulfur,Uranium
	//weights refer to atomic mass
	public static List<string> minerals = new List<string>{"H2O","FE2","U"};
	public static List<float> mineralWeights = new List<float>{18,112,235};

	//Gasses used in the game
	//Oxygen, nitrogen, methane, carbon-dioxide, hydrogen
	//weights refer to atomic mass
	public static List<string> gasses = new List<string>{"O2","CO2","H2"};
	public static List<float> gasWeights = new List<float>{32,44,2};

	//organic materials used in the game
	//Oxygen, nitrogen, methane, carbon-dioxide, hydrogen
	//weights refer to atomic mass
	public static List<string> organics = new List<string>{"Blood","Clorophyll","Sugar"};
	public static List<float> organicWeights = new List<float>{1,1};

	//energy types used in the game
	//Heat, Light, Radiation, Movement, Life
	//weight refers to how useful said resource is
	public static List<string> energies = new List<string>{"Life","Light","Movement"};
	public static List<float> energyWeights = new List<float>{1,1};

	/***************************************************
	 * Time functions to speed up/slow down the game, pause etc.
	 * ************************************************/
	public static bool paused;

	public static void Pause()
	{
		Time.timeScale = 0;
		paused = true;
	}
	public static void Resume()
	{
		Time.timeScale = 1;
		paused = false;
	}

	/*********************************************************************************88***
	 * Control explored and unexplored planets and which planet is the focus at this moment
	 * ***********************************************************************************/
	//object camera is focusing on
	public static Transform focusObject;
	//camera zoom
	public static float zoom = 1;

	//Known and unknown planets
	public static List<Transform> knownPlanets = new List<Transform>();
	//List of all planents by transform, parent
	public static Dictionary<Transform,Transform> allPlanets = new Dictionary<Transform, Transform>();

	private static void ListPLanets()
	{
		foreach(GameObject planet in GameObject.FindGameObjectsWithTag("Planet"))
		{
			if(!allPlanets.ContainsKey(planet.transform))
			{
				if(planet.transform.parent != null) allPlanets.Add(planet.transform, planet.transform.parent);
			}
		}
	}

	public static List<Transform> ChildrenPlanets(Transform parent)
	{
		List<Transform> childList = new List<Transform>();

		ListPLanets ();

		foreach(KeyValuePair<Transform,Transform> Planets in allPlanets)
		{
			if(Planets.Value == parent) childList.Add(Planets.Key);
		}
		if (childList.Count > 0)
		{
			childList.Sort (delegate(Transform x, Transform y) 
			{
				float xOrbit = x.GetComponent<Planet>().Orbit;
				float yOrbit = y.GetComponent<Planet>().Orbit;
				return xOrbit.CompareTo(yOrbit);
			});
			return childList;
		}
		else return null;
	}

	/*********************************************************************
	 * functions involving species
	 * ****************************************************************/
	//if True change cursor and add bacteria to selected tile
	//contains a list of all species names to prevent duplication
	public static List<string> nameList = new List<string>();

	public static bool addBacteria;
	public static Bacteria newBacteria;
	public static int newBacteriaQuantity;
}

class intVector2
{
	public int x;
	public int y;

	public intVector2(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
}