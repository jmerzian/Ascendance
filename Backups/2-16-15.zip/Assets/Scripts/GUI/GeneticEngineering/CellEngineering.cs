using UnityEngine;
using System.Collections;
using System.Collections.Generic;
//TODO finish up the interface for creating the different kinds of cells
public static class CellEngineering
{
	/*************************
	 * Holder Variables
	 * ***************************/
	//holder for all saved cells
	public static Dictionary<string,Cell> savedCells = new Dictionary<string,Cell>();
	//Temporary holder for the finsihed cell properties
	private static string name = "New Cell";
	private static Cell tempCell = new Cell ();
	//transporter efficiency variable
	private static float[] transports = new float[2];
	private static string[] transportString = new string[]{"Size","Efficiency"};

	//Dictates what type of cell is being created
	public static bool[] cellDisplay = new bool[]{false,false,false,false,false,false,false};
	public static string[] cellName = new string[]{"Producer","Transport","Structural","Utility"};

	//GUI variables
	private static Vector2[] scroll = new Vector2[8];
	private static int outputTextRows;

	//loops between renders... ideally speeds up operation
	private static float renderTime = 20;
	private static int loops = 0;

	public static void CreateCell(int ID)
	{
		//since the 
		//Pause the game and adjust the render to happen once per second
		Control.Pause ();

		//iterator... used in foreach loops
		int i = 0;
	
		/**************************************
		 * Top Row selects what type of cell is being created
		 * ********************************************/
		GUI.BeginGroup(new Rect(10,10,480,20));
		for(int j = 0; j < cellName.Length; j++)
		{
			cellDisplay[j] = GUI.Toggle (new Rect(120*j,0,120,30),cellDisplay[j],cellName[j]);
			if(cellDisplay[j])
			{
				tempCell.type = cellName[j];
				for(int k = 0; k < cellName.Length; k++)
				{
					if(j != k) cellDisplay[k] = false;
				}
			}
		}
		GUI.EndGroup();
		/*************************************************
		 * Left Collumn determines inputs
		 * ************************************************/
		GUI.BeginGroup (new Rect (20, 40, 300, Screen.height));
		//name of cell
		name = GUI.TextField(new Rect(0,0,300,20),name);
		//height of section
		float sectionHeight = (Screen.height-240) / 4;

		/*******************************
		 * Producer and transport
		 * ****************************/
		if(cellDisplay[0] || cellDisplay[1])
		{
			//if producer use to select energy
			if(cellDisplay[0])
			{
				GUI.Label (new Rect (0,40,240,24), "Energy Sources");
				scroll[3] = GUI.BeginScrollView (new Rect(0,64,260,sectionHeight), scroll[3], new Rect(0, 0, 240,Control.energies.Count*40));
				i = 0;
				foreach(string energy in Control.energies)
				{
					GUI.Label(new Rect(0,40*i,80,40),Control.energies[i]);
					tempCell.energyIn[energy] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),tempCell.energyIn[energy],0,1);
					i++;
				}
				GUI.EndScrollView();
			}
			//otherwise show controls for storage amount
			else
			{
				GUI.Label (new Rect (0,40,240,24), "Storage Size");
				scroll[3] = GUI.BeginScrollView (new Rect(0,64,260,sectionHeight), scroll[3], new Rect(0, 0, 240,Control.energies.Count*40));
				for(i = 0; i < transports.Length; i++)
				{
					GUI.Label(new Rect(0,40*i,80,40),transportString[i]);
					transports[i] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),transports[i],0,1);
				}
				GUI.EndScrollView();
			}

			GUI.Label (new Rect (0,80+sectionHeight,240,24), "Organic Materials Used");
			scroll[2] = GUI.BeginScrollView (new Rect(0,104+sectionHeight,260,sectionHeight), scroll[2], new Rect(0, 0, 240,Control.organics.Count*40));
			i = 0;
			foreach(string organic in Control.organics)
			{
				GUI.Label(new Rect(0,40*i,80,40),Control.organics[i]);
				tempCell.resourceIn[organic] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),tempCell.resourceIn[organic],0,1);
				i++;
			}
			GUI.EndScrollView();

			GUI.Label (new Rect (0,120+2*sectionHeight,240,24), "Minerals Used");
			scroll[1] = GUI.BeginScrollView (new Rect(0,144+2*sectionHeight,260,sectionHeight), scroll[1], new Rect(0, 0, 240,Control.minerals.Count*40));
			i = 0;
			foreach(string mineral in Control.minerals)
			{
				GUI.Label(new Rect(0,40*i,80,40),Control.minerals[i]);
				tempCell.resourceIn[mineral] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),tempCell.resourceIn[mineral],0,1);
				i++;
			}
			GUI.EndScrollView ();

			GUI.Label (new Rect (0,160+3*sectionHeight,240,24), "Gasses Used");
			scroll[0] = GUI.BeginScrollView (new Rect(0,184+ 3*sectionHeight,260,sectionHeight), scroll[0], new Rect(0, 0, 240,Control.gasses.Count*40));
			i = 0;
			foreach(string gas in Control.gasses)
			{
				GUI.Label(new Rect(0,40*i,80,40),Control.gasses[i]);
				tempCell.resourceIn[gas] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),tempCell.resourceIn[gas],0,1);
				i++;
			}
			GUI.EndScrollView ();
		}
		GUI.EndGroup ();

		/******************************************************************
		 * Center contains viewport for what the finished cell looks like and maybe some other things at the bottom....
		 * ***************************************************************/
		GUI.BeginGroup (new Rect(Screen.width/2 - 160,40,320,320));
		GUI.DrawTexture (new Rect(0,0,320,320),tempCell.sprite);
		GUI.EndGroup ();

		/***************************
		 * Clear all of the outpus to make sure an accurate value is output
		 * ***************************/
		foreach(string energy in Control.energies)
		{
			tempCell.energyOut[energy] = 0;
		}
		foreach(string resource in Control.minerals)
		{
			tempCell.resourceOut[resource] = 0;
		}
		foreach(string resource in Control.gasses)
		{
			tempCell.resourceOut[resource] = 0;
		}
		foreach(string resource in Control.organics)
		{
			tempCell.resourceOut[resource] = 0;
		}
		//Because life is wierd...
		tempCell.minimumToLive = 0;
		tempCell.energyOut ["Life"] = 1;
		/******************************************************************
		 * Right collumn shows what the byproducts are, nutrients needed etc.
		 * ***************************************************************/
		GUI.BeginGroup (new Rect(Screen.width-240,20,240,Screen.height));
		//If producer show what is being produced
		//If transporter show what is being transported
		//If structural.. TODO something
		//If other... TODO something
		/*******************
		 * Producers
		 * *********************/
		if(cellDisplay[0])
		{
			GUI.Label(new Rect(0,0,240,40),"Resources Consumed");
			scroll[4] = GUI.BeginScrollView (new Rect(0,20,240,Screen.height-360), scroll[4], new Rect(0, 0, 220,outputTextRows*20));
			i = 0;
			foreach (KeyValuePair<string, float> energy in tempCell.energyIn)
			{
				foreach(KeyValuePair<string, float> resource in tempCell.resourceIn)
				{
					string result = null;
					if(resource.Value > 0) result = Recipes.recipes[energy.Key].getResult(resource.Key);
					if(result != null)
					{
						//check if it's an energy that is being released
						if(Control.energies.Contains(result))
						{
							if(!tempCell.energyOut.ContainsKey(result))tempCell.energyOut.Add(result,energy.Value*resource.Value);
							else tempCell.energyOut[result] += energy.Value*resource.Value;
							GUI.Label(new Rect(0,20*i,200,20),"1 " + energy.Key + " + 1 " + resource.Key + " = " + 
							          energy.Value*resource.Value + " " + result);
							tempCell.minimumToLive+=tempCell.energyOut[result]/2;
						}
						else
						{
							if(!tempCell.resourceOut.ContainsKey(result))tempCell.resourceOut.Add(result,energy.Value*resource.Value);
							else tempCell.resourceOut[result] += energy.Value*resource.Value;
							GUI.Label(new Rect(0,20*i,200,20),"1 " + energy.Key + " + 1 " + resource.Key + " = " + 
							          (energy.Value*resource.Value).ToString("F4") + " " + result);
							tempCell.minimumToLive+=tempCell.resourceOut[result]/2;
						}
						i++;
					}
				}
			}
			outputTextRows = i;
			GUI.EndScrollView ();

			GUI.Label(new Rect(0,360,240,40),"Energy Outputs");
			scroll[5] = GUI.BeginScrollView (new Rect(0,400,240,Screen.height-120), scroll[5], new Rect(0, 0, 220,outputTextRows*40));
			i = 0;
			foreach (KeyValuePair<string, float> energy in tempCell.energyOut)
			{
				GUI.Label(new Rect(0,20*i,200,20),energy.Key + " " + energy.Value.ToString("F4"));
				i++;
			}
			outputTextRows = i;
			GUI.EndScrollView ();
		}
		/************************
		 * transporters
		 * **********************/
		else if(cellDisplay[1])
		{
			GUI.Label(new Rect(0,0,240,40),"Resources Stored");
			scroll[4] = GUI.BeginScrollView (new Rect(0,40,240,Screen.height-360), scroll[4], new Rect(0, 0, 220,outputTextRows*20));
			i = 0;
			foreach(KeyValuePair<string,float> resource in tempCell.resourceIn)
			{
				if(resource.Value > 0)
				{
					GUI.Label(new Rect(0,20*i,240,20),"stores " + (transports[1]*90).ToString("F2") + "% of each " + resource.Key);
					i++;
					GUI.Label(new Rect(0,20*i,240,20),"stores a maximum of " + (transports[0]*resource.Value*10).ToString("F2") + " of " + resource.Key);
					//minimum to live is calculated by size*efficieny of transport*efficiency of material
					tempCell.minimumToLive += transports[0]*transports[1]*resource.Value;
					tempCell.resourceOut[resource.Key] = transports[1]*0.9f;
					i++;
				}
			}
			outputTextRows = i;
			GUI.EndScrollView();
		}
		GUI.Label(new Rect(0,Screen.height-120,200,40),"Needs a minimum of " + tempCell.minimumToLive.ToString("F4") + " resources (per million) to live");
		if (loops > renderTime)
		{
			drawCell ();
			loops = 0;
		}
		else loops++;
		if(GUI.Button(new Rect(0,Screen.height-60,100,30),"Save Cell"))
		{
			//Run checks to make sure that it is a valid Cell
			if(ValidCell())
			{
				tempCell.name = name;
				savedCells.Add(name,new Cell(tempCell));
				tempCell = new Cell();
				GUIMain.windowDisplay[6] = false;
			}
		}
		if(GUI.Button(new Rect(100,Screen.height-60,100,30),"Close"))
		{
			GUIMain.windowDisplay[6] = false;
		}
		GUI.EndGroup ();
	}

	/********************************************
	 * Check to see if the cell is valid
	 * *************************************/
	private static bool ValidCell()
	{
		if (savedCells.ContainsKey (name))return false;
		if(tempCell.minimumToLive > 1) return false;
		return true;
	}

	/*****************************************
	 * Draw Cell
	 * ***************************************/
	public static void drawCell()
	{
		for(int i = 0; i < cellName.Length; i++) if(cellDisplay[i]) TextureHelper.Copy(ref tempCell.sprite,CellTextures.textures[cellName[i]]);
		foreach(KeyValuePair<string,float> resource in tempCell.resourceOut)
		{
			if(resource.Value>0)tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures[resource.Key],tempCell.sprite,0.5f+resource.Value/4);
			tempCell.sprite.Apply();
		}
		foreach(KeyValuePair<string,float> resource in tempCell.energyOut)
		{
			if(resource.Value>0 && resource.Key != "Life")tempCell.sprite = TextureHelper.CombineTextures(CellTextures.textures[resource.Key],tempCell.sprite,0.5f+resource.Value/4);
			tempCell.sprite.Apply();
		}
	}
}