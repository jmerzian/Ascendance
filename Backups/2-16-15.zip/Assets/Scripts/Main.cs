﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Main : MonoBehaviour 
{
	public Texture2D loadingMenu;
	bool go;
	bool loaded;
	private int loadingProgress;
	private string[] loadingMessage = new string[]
	{
		"Imaging Microbes",
		"Devising Devious Concoctions",
		"Gathering critters from home",
		"Organizing Otherworldly Blueprints"
	};

	void Start ()
	{
		loaded = false;
		go = false;
		StartCoroutine(LoadScene ());
	}

	void OnGUI()
	{
		//Set the skin
		GUI.skin = GUIMain.skin;
		if(!go)
		{
			GUI.DrawTexture(new Rect(0,0,Screen.width,Screen.height),loadingMenu);
			if(loaded)
			{
				if(GUI.Button(new Rect(Screen.width/2-120,Screen.height-240,240,40),"GO"))
				{
					go = true;
					//Show GE window
					//GUIMain.windowDisplay [4] = true;
				}
			}
			else
			{
				GUI.Label(new Rect(Screen.width/2-240,Screen.height-240,480,40),loadingMessage[loadingProgress]);
			}
		}
	}

	private IEnumerator LoadScene()
	{
		/*****************************
		 * Load things
		 * ******************************/
		//TODO delete this... it's solely for testing purposes
		//load cell textures
		CellTextures.initTextures();
		loadingProgress = 0;
		yield return null;
		//initialize the windows
		Recipes.initRecipes();
		loadingProgress = 1;
		yield return null;
		//load default cells
		ExampleCells.loadCells();
		for(int z = 0; z < ExampleCells.testCellNames.Length; z++) CellEngineering.savedCells.Add(ExampleCells.testCellNames[z],ExampleCells.testCells[z]);
		loadingProgress = 2;
		yield return null;
		//initialize the Bacteria GE grid
		GeneticEngineering.ClearGrid ();
		loadingProgress = 3;
		yield return null;
		loaded = true;
	}

	//Control the game flow from here
	void Update () 
	{		
	}
}
