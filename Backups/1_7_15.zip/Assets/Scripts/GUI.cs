using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Ascendance;
using Resources;

namespace GUIControl
{
	public class GUIFrame
	{
		//List of all known planets
		private List<Transform> knownPlanets = new List<Transform>();
		
		public void OnGUI()
		{
			if(GUIDisplay.printPlanet)
			{
				//display all of the planet information in a clear concise beautiful way
				PlanetInformation(GUIDisplay.printedPlanet);
			}
			if(GUIDisplay.printBiome)
			{
				//display all of the biome information in a clear concise beautiful way
				BiomeInformation(GUIDisplay.printedBiome);
			}
		}

		private void PlanetInformation(Planet selectedPlanet)
		{
			if(selectedPlanet.resources.hasAtmosphere())
			{
				GUI.Box (new Rect(0,0,120,120),"Planet Information \n" +
					"Pressure: " + selectedPlanet.resources.getPressure(selectedPlanet.Radius)+
				    "\nOxygen: " + selectedPlanet.resources.gasQuantities[0]+
				    "\nNitrogen: " + selectedPlanet.resources.gasQuantities[1]+
				    "\nMethane: " + selectedPlanet.resources.gasQuantities[2]+
				    "\nCarbon Dioxide: " + selectedPlanet.resources.gasQuantities[3]+
				    "\nHydrogen: " + selectedPlanet.resources.gasQuantities[4]);
			}
			else GUI.Box (new Rect(0,0,120,120),"Planet Information \nHas no atmosphere.");
		}

		private void BiomeInformation(Biome selectedBiome)
		{
			//water, ammonia, calcium, Iron, Sulfur,Uranium
			GUI.Box (new Rect(0,120,120,120),"Biome Information \n" +
			         "Water: " + selectedBiome.resources.mineralQuantities[0]+
			         "\nAmmonia: " + selectedBiome.resources.mineralQuantities[1]+
			         "\nCalcium: " + selectedBiome.resources.mineralQuantities[2]+
			         "\nIron: " + selectedBiome.resources.mineralQuantities[3]+
			         "\nSulfur: " + selectedBiome.resources.mineralQuantities[4]+
			         "\nUranium: " + selectedBiome.resources.mineralQuantities[5]);
		}
	}
	public static class GUIDisplay
	{
		//whether or not to display the biome or planet information
		public static bool printBiome;
		public static bool printPlanet;

		//which biome or planet to print
		public static Biome printedBiome;
		public static Planet printedPlanet;

		public static void PrintBiome(Biome selectedBiome, Planet selectedPlanet)
		{
			//siplay information about the currently selected biome
			if(selectedBiome != null)
			{
				printBiome = true;
				printedBiome = selectedBiome;
				printedPlanet = selectedPlanet;
			}
			else
			{
				printBiome = false;
			}
		}

		public static void PrintPlanet(Planet selectedPlanet)
		{
			//siplay information about the currently selected planet
			if(selectedPlanet != null)
			{
				printPlanet = true;
				printedPlanet = selectedPlanet;
			}
			else if(printBiome == true)
			{
				printPlanet = true;
			}
			else
			{
				printPlanet = false;
			}
		}
	}
	public static class GUIAction
	{
		public static void SelectBiome(Transform selectedBiome)
		{
			if(selectedBiome != null)
			{
				Planet selectedPlanet = selectedBiome.parent.GetComponent<Planet>();
				//If valid Biome is selected display information about that biome
				Dictionary<Transform,Biome> planetBiomes = selectedPlanet.GetPlanetBiomes();
				if(planetBiomes.ContainsKey(selectedBiome))
				{
					GUIDisplay.PrintBiome(planetBiomes[selectedBiome],selectedPlanet);
				}
				else
				{
					Debug.LogError("Uncategorized biome... get yo biomes together bro");
				}
			}
			else
			{
				GUIDisplay.PrintBiome(null,null);
			}
		}

		public static void SelectPlanet(Transform selectedPlanet)
		{
			if(selectedPlanet != null)
			{
				GUIDisplay.PrintPlanet (selectedPlanet.GetComponent<Planet>());
			}
			else
			{
				GUIDisplay.PrintPlanet(null);
			}
		}
	}
}