using UnityEngine;
using System.Collections;

public class Sun : Planet
{
		// Use this for initialization
		public override void Start ()
		{
			//Position the sun at the center... maybe do something else eventually...
			transform.position = new Vector3 (0, 0, 0);
			transform.localScale = new Vector3 (base.Radius, base.Radius);
		}
	
		// Update is called once per frame
		public override void Update ()
		{
			//Sun does nothing... just sits there
		}
}

