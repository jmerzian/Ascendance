using UnityEngine;
using System.Collections;

public static class TextureCopy
{
	//helper function to copy textures
	public static void copy(Texture2D output, Texture2D source)
	{
		Color[] textureData = source.GetPixels ();
		output.SetPixels (textureData);
	}

	public static Texture2D combineTextures(Texture2D Araw, Rect Apos, Texture2D Braw, Rect Bpos)
	{
		int width = (int)(Bpos.x - Apos.x + Bpos.width);
		int height = (int)(Bpos.y - Apos.y + Bpos.height);
		
		Texture2D finalTexture = new Texture2D(width,height);
		Color nothing = new Color(0,0,0,0);
		
		//create new texture to prevent altering the original
		Texture2D A = new Texture2D (Araw.width,Araw.height);
		//copy the data to the new texture
		TextureCopy.copy (A, Araw);
		//scale the image to the right dimensions
		TextureScale.Bilinear (A, (int)Apos.width, (int)Apos.height);
		//rinse and repeat
		Texture2D B = new Texture2D (Araw.width,Araw.height);
		TextureCopy.copy (B, Braw);
		TextureScale.Bilinear (B, (int)Bpos.width, (int)Bpos.height);
		
		int debugA = 0;
		int debugB = 0;
		int debugAB = 0;
		int debugX = 0;
		bool aFrame = false;
		bool bFrame = false;
		
		//TODO ugly, find a better way
		Debug.Log (width + " " + height);
		for(int x = 0; x < width; x++)
		{
			for(int y = 0; y <height; y ++)
			{
				//within the A reference frame in the X direction
				if(Apos.x < x && x < (Apos.x+Apos.width))
				{
					if(Apos.y < y && y < (Apos.y+Apos.height)) aFrame = true;
					else aFrame = false;
				}
				if(Bpos.x < x && x < (Bpos.x+Bpos.width))
				{
					if(Bpos.y < y &&  y < (Bpos.y+Bpos.height)) bFrame = true;
					else bFrame = false;
				}

				if(aFrame && bFrame)
				{
					finalTexture.SetPixel(x,y, combineColors(A.GetPixel((int)(x-Apos.x),(int)(y-Apos.y)),B.GetPixel((int)(x-Bpos.x),(int)(y-Bpos.y))));
					debugAB++;
				}
				else if(aFrame && !bFrame) 
				{
					finalTexture.SetPixel(x,y,A.GetPixel((int)(x-Apos.x),(int)(y-Apos.y))); 
					debugA++;
				}
				else if(!aFrame && bFrame)
				{
						finalTexture.SetPixel(x,y,B.GetPixel((int)(x-Bpos.x),(int)(y-Bpos.y))); 
					debugB++;
				}
				else 
				{
					finalTexture.SetPixel(x,y,nothing);
					debugX++;
				}
			}
		}
		//Turn colors back into texture
		finalTexture.Apply ();
		Debug.Log (Apos.width + " a reference frame\n" + Bpos.width + " b reference frame");
		Debug.Log (debugA + " A pixels added\n" + debugB + " B pixels added");
		Debug.Log (debugAB + " AB pixels added\n" + debugX + " X pixels added");
		
		return finalTexture;
	}
	private static Color combineColors(Color A, Color B)
	{
		if(A.a > 0)
		{
			if(B.a>0)
			{
				return new Color(A.r*A.a/(B.r*B.a),A.b*A.a/(B.b*B.a),A.r*A.a/(B.r*B.a),A.a+B.a);
			}
			else return A;
		}
		else if(B.a > 0)
		{
			return B;
		}
		else return new Color(0,0,0,0);
	}
}

