using UnityEngine;
using System;
using System.Collections.Generic;

public class BacteriaRender
{
	//list of creature characteristics
	public float size;
	public float temp;
	public List<Texture2D> mouths = new List<Texture2D>();
	public List<Texture2D> heads = new List<Texture2D>();
	public List<Texture2D> bodies = new List<Texture2D>();
	public List<Texture2D> tails = new List<Texture2D>();

	//list of node locations(where to place the next object
	private Vector2[] nodeLocation = new Vector2[4];
	private float[] largest = new float[3];

	//list of texture scalings
	private Vector2 scaling;

	//What the Creature will look like
	private Texture2D finalCreature = new Texture2D(1200,1200);

	public Texture2D renderCreature(float size, float temp,float[] movement, float[] nutrients, float[] energy)
	{
		loadTextures ();

		List<float> sortedMovement = new List<float>(movement);
		sortedMovement.Sort ();
		largest[0] = sortedMovement[0];

		List<float> sortedNutrients = new List<float>(nutrients);
		sortedNutrients.Sort ();
		largest[1] = sortedNutrients[0];

		List<float> sortedEnergy = new List<float>(energy);
		sortedEnergy.Sort ();
		largest[2] = sortedEnergy[0];
		
		//TODO TERRIBLY ugly in the process of revamping system
		//find the largest object, this will be the largest within that group and will be needed to calculate where everything is placed
		//movement
		/*
		if(movement[0] > movement [2]) tailScale.y = movement[0];
		else tailScale.y = movement[2];

		bodyScale.y = movement [3];

		headScale.y = 1+movement [1];

		//nutrients
		float highestValue = 0;
		for(int i =0; i < nutrients.Length; i++)
		{
			if(nutrients[i] > highestValue) highestValue = nutrients[i];
		}
		mouthScale.y = highestValue;

		//energy
		bodyScale.x = tailScale.x = energy [0];
		headScale.x = 1+energy [1];

		//calculate the size of the creature and it's center
		Vector2 creatureSize = new Vector2 ();
		highestValue = tailScale.x;
		if(bodyScale.x > highestValue) highestValue = bodyScale.x;
		if(headScale.x > highestValue) highestValue = headScale.x;
		if(mouthScale.x > highestValue) highestValue = mouthScale.x;

		creatureSize.x = highestValue;//Largest of the X dimensions
		creatureSize.y = (tailScale.y)+(bodyScale.y)+(headScale.y)+(mouthScale.y);

		mouthNode = new Vector2 (creatureSize.x/2-mouthScale.x/2,0);
		headNode = new Vector2 (creatureSize.x/2-headScale.x/2,mouthScale.y);
		bodyNode = new Vector2 (creatureSize.x/2-bodyScale.x/2,headNode.y+headScale.y);
		tailNode = new Vector2 (creatureSize.x/2-tailScale.x/2,bodyNode.y+bodyScale.y);
		*/

		return finalCreature;
	}

	private void loadTextures()
	{
		mouths = CreatureTextures.bacteriaTextures["Mouths"];
		heads = CreatureTextures.bacteriaTextures["Heads"];
		bodies = CreatureTextures.bacteriaTextures["Bodies"];
		tails = CreatureTextures.bacteriaTextures["Tails"];
	}
}

