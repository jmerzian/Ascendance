using UnityEngine;
using System.Collections;


public static class BacteriaEngineering
{
	//Check to see if something has changed
	private static bool changed = false;
	//General bacteria information\
	private static string name = "OmNom";
	private static float size;
	private static float temperature;
	
	//Bacteria Renderer
	private static BacteriaRender renderer = new BacteriaRender ();
	private static Texture2D creature = new Texture2D (255,255);
	
	//Bacteria movement fields
	private static bool[] movementTypes = new bool[]{false,false,false,false};
	private static float[] movementValue = new float[]{0,0,0,0};
	
	//Bacteria nutrient fields
	private static bool[] nutrientTypes = new bool[]{false,false,false,false};
	private static float[] nutrientValue = new float[]{0,0,0,0};
	
	//Bacteria energy fields
	private static bool[] energyTypes = new bool[]{false,false,false,false};
	private static float[] energyValue = new float[]{0,0,0,0};
	
	public static void information()
	{
		engineeringControls ();
		creatureInformation ();
		if(GUI.Button(new Rect(8,Screen.height-20,255,20),"Create Creature"))
		{
			if(changed == false)
			{
				creature = renderer.renderCreature (size,temperature,movementValue,nutrientValue,energyValue);
			}
			changed = true;
		}
		else 
		{
			changed = false;
		}
		creatureWindow ();
	}
	
	private static void creatureWindow()
	{
		GUI.BeginGroup (new Rect (270, 40, Screen.width-510,Screen.height-255));
		GUI.Box (new Rect (0,0,Screen.width-510,Screen.height-255), creature);
		GUI.EndGroup ();
	}
	
	private static void creatureInformation()
	{
		//TODO show information about the creature being created
	}
	
	private static void engineeringControls()
	{
		name = GUI.TextArea(new Rect(8,40,255,20),name);
		GUI.BeginGroup(new Rect(0,40,255,Screen.height));
		GUI.BeginGroup (new Rect (8, 40, 255, 40));
		GUI.Label (new Rect (0, 0, 64,20), "Size");
		size = GUI.HorizontalSlider (new Rect(80,0,170,20),size,0.1f,10);
		GUI.Label (new Rect (0, 20, 64,20), "Ideal Temp");
		temperature = GUI.HorizontalSlider (new Rect(80,20,170,20),temperature,0.1f,10);
		GUI.EndGroup ();
		
		GUI.BeginGroup(new Rect(8,80,255,480));
		GUI.BeginGroup (new Rect (0, 0, 255, 255));
		//Set up the controls for engineering bacterium
		GUI.Box (new Rect (0, 0, 255, 20),"Movement Capabilities");
		
		for(int i = 0; i < BacteriaStrings.movementTypes.Length; i++)
		{
			movementTypes[i] = GUI.Toggle(new Rect(0,24*i + 20,64,20),movementTypes[i],BacteriaStrings.movementTypes[i]);
			if(movementTypes[i])
			{
				movementValue[i] =  GUI.HorizontalSlider(new Rect(80,24*i + 20,170,20),movementValue[i],0.1f,10);
			}
			else movementValue[i] = 0;
		}
		GUI.EndGroup ();
		
		GUI.BeginGroup (new Rect (0, 160, 255, 255));
		//Set up the controls for engineering bacterium
		GUI.Box (new Rect (0, 0, 255, 20),"Nutrient Sources");
		
		for(int i = 0; i < BacteriaStrings.nutrientTypes.Length; i++)
		{
			nutrientTypes[i] = GUI.Toggle(new Rect(0,24*i + 20,64,20),nutrientTypes[i],BacteriaStrings.nutrientTypes[i]);
			if(nutrientTypes[i])
			{
				nutrientValue[i] =  GUI.HorizontalSlider(new Rect(80,24*i + 20,170,20),nutrientValue[i],0.1f,10);
			}
			else nutrientValue[i] = 0;
		}
		GUI.EndGroup ();
		
		GUI.BeginGroup (new Rect (0, 320, 255, 255));
		//Set up the controls for engineering bacterium
		GUI.Box (new Rect (0, 0, 255, 20),"Energy Sources");
		
		for(int i = 0; i < BacteriaStrings.energyTypes.Length; i++)
		{
			energyTypes[i] = GUI.Toggle(new Rect(0,24*i + 20,64,20),energyTypes[i],BacteriaStrings.energyTypes[i]);
			if(energyTypes[i])
			{
				energyValue[i] =  GUI.HorizontalSlider(new Rect(80,24*i + 20,170,20),energyValue[i],0.1f,10);
			}
			else energyValue[i] = 0;
		}
		GUI.EndGroup ();
		GUI.EndGroup();
		GUI.EndGroup();
		
		if(GUI.Button(new Rect(Screen.width-240,Screen.height-20,120,20),"Release Specimen"))
		{
			if(!Control.nameList.Contains(name))
			{
				Control.addBacteria = true;
				Control.newBacteria = new Bacteria(name,movementValue,nutrientValue,energyValue);
				Control.newBacteriaQuantity = 10;
				GUIMain.windowDisplay[4] = false;
			}
			else
			{
				name = "NEEDS A UNIQUE NAME";
			}
		}
	}
}


