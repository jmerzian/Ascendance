using UnityEngine;
using System.Collections;

public static class GeneticEngineering
{
	//Set of bools to detect which animal group is being editted
	private static bool bacteriaEdit;
	private static bool plantEdit;
	private static bool animalEdit;

	public static void windowDisplay(int ID)
	{
		//pause the game
		Control.Pause ();

		GUI.BeginGroup(new Rect(8,20,255,20));
		bacteriaEdit = GUI.Toggle (new Rect(0,0,64,20),bacteriaEdit,"Bacteria");
		plantEdit = GUI.Toggle (new Rect(80,0,64,20),plantEdit, "Plants");
		animalEdit = GUI.Toggle (new Rect(160,0,64,20),animalEdit, "Animals");
		GUI.EndGroup();

		//Display all information to engineer a creature
		if(bacteriaEdit)
		{
			BacteriaEngineering.information();
			plantEdit = false;
			animalEdit = false;
		}
		if(plantEdit)
		{
			plantEngineering();
			bacteriaEdit = false;
			animalEdit = false;
		}
		if(animalEdit)
		{
			animalEngineering();
			bacteriaEdit = false;
			plantEdit = false;
		}

		if(GUI.Button(new Rect(Screen.width-120,Screen.height-20,120,20),"Close"))
		{
			GUIMain.windowDisplay[4] = false;
		}
	}
	private static void plantEngineering()
	{
	}
	private static void animalEngineering()
	{
	}
}

