using UnityEngine;
using System.Collections.Generic;

public class CreatureTextures:MonoBehaviour
{
	//images taken from inspector
	public List<Texture2D> bacteriaMouths;
	public List<Texture2D> bacteriaHeads;
	public List<Texture2D> bacteriaBodies;
	public List<Texture2D> bacteriaTails;

	//static class to access images
	public static Dictionary<string,List<Texture2D>> bacteriaTextures = new Dictionary<string,List<Texture2D>>();

	void Start()
	{
		bacteriaTextures.Add ("Mouths", bacteriaMouths);
		bacteriaTextures.Add ("Heads", bacteriaHeads);
		bacteriaTextures.Add ("Bodies", bacteriaBodies);
		bacteriaTextures.Add ("Tails", bacteriaTails);
	}
}

