using UnityEngine;
using System;
using System.Collections.Generic;

public static class BacteriaStrings
{
	public static string[] movementTypes = new string[]{"water","air","organism","soil"};
	public static string[] nutrientTypes = new string[]{"mineral","animal","air"};
	public static string[] energyTypes = new string[]{"heat","light","radiation"};
}

public class Bacteria : Creature
{
	//if the bacteria is parasitic or not
	public bool parasitic;

	/*******************************************************8
	 * Mediums the bacteria is capable of moving through
	 * *********************************************************/
	public Dictionary<string,bool> movementCapable = new Dictionary<string,bool>();
	public Dictionary<string,float> movementSpeed = new Dictionary<string,float>();

	/****************************************************************
	 * Sources of nutrients available to bacteria
	 * ***************************************************************/
	public Dictionary<string,bool> nutrientCapable = new Dictionary<string,bool>();
	public Dictionary<string,float> nutrientEfficiency = new Dictionary<string,float>();

	/***********************************************************************
	 * Sources of energy available to bacteria
	 * *********************************************************************/
	public Dictionary<string,bool> energyCapable = new Dictionary<string,bool>();
	public Dictionary<string,float> energyEfficiency = new Dictionary<string,float>();

	public Bacteria()
	{
		foreach(string movement in BacteriaStrings.movementTypes)
		{
			movementCapable.Add(movement,false);
			movementSpeed.Add(movement,0);
		}
		foreach(string nutrient in BacteriaStrings.nutrientTypes)
		{
			nutrientCapable.Add(nutrient,false);
			nutrientEfficiency.Add(nutrient,0);
		}
		foreach(string energy in BacteriaStrings.energyTypes)
		{
			energyCapable.Add(energy,false);
			energyEfficiency.Add(energy,0);
		}
	}

	public Bacteria (string newName, float[] movement, float[] nutrient, float[] energy) : this()
	{
		name = newName;

		//modify each value of the dictionary
		for(int i = 0; i < BacteriaStrings.movementTypes.Length; i++)
		{
			movementSpeed[BacteriaStrings.movementTypes[i]] = movement[i];
			if(movement[i]>0) movementCapable[BacteriaStrings.movementTypes[i]] = true;
		}

		//modify each value of the dictionary
		for(int i = 0; i < BacteriaStrings.nutrientTypes.Length; i++)
		{
			nutrientEfficiency[BacteriaStrings.nutrientTypes[i]] = nutrient[i];
			if(nutrient[i]>0) nutrientCapable[BacteriaStrings.nutrientTypes[i]] = true;
		}

		//modify each value of the dictionary
		for(int i = 0; i < BacteriaStrings.energyTypes.Length; i++)
		{
			energyEfficiency[BacteriaStrings.energyTypes[i]] = energy[i];
			if(energy[i]>0) energyCapable[BacteriaStrings.energyTypes[i]] = true;
		}
	}
}