using UnityEngine;
using System.Collections.Generic;
using Resources;

public class Creature
{
	//Creature name
	public string name;
	//size of the Creature, relates to nutrients needed
	public float size;
	//Range of temperatures the bacteria can survive in
	public float[] tempRange = new float[]{0,1};
	//rate of reproduction
	public float reproduciton;
	//chemistry
	public Dictionary<string,float> gasUse = new Dictionary<string, float>();
	public Dictionary<string,float> mineralUse = new Dictionary<string, float>();

	public Creature()
	{
		foreach(string gas in Control.gasses)
		{
			gasUse.Add(gas,0);
		}
		foreach(string mineral in Control.minerals)
		{
			mineralUse.Add(mineral,0);
		}
	}

	public Creature(float[] gasEfficiency, float[] mineralEfficiency):this()
	{
		int iterations = 0;
		if(gasEfficiency.Length < Control.gasses.Count)iterations = gasEfficiency.Length;
		else iterations = Control.gasses.Count;
		
		for(int i = 0; i < iterations; i ++)
		{
			gasUse[Control.gasses[i]] = gasEfficiency[i];
		}

		iterations = 0;
		if(mineralEfficiency.Length < Control.minerals.Count)iterations = mineralEfficiency.Length;
		else iterations = Control.minerals.Count;
		
		for(int i = 0; i < iterations; i ++)
		{
			mineralUse[Control.minerals[i]] = gasEfficiency[i];
		}
	}
}

public class BacteriaSpecies
{
	public int quantity;
	public Bacteria bacteria;

	public BacteriaSpecies(Bacteria baseBacteria, int speciesQuantity)
	{
		quantity = speciesQuantity;
		bacteria = baseBacteria;
	}
}