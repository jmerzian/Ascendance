using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Organism
{
	public string genus;
	public string species;

	public Dictionary<string, float> resourceIn = new Dictionary<string, float>();
	public Dictionary<string, float> resourceOut = new Dictionary<string, float>();

	public Dictionary<string, float> energyIn = new Dictionary<string, float>();
	public Dictionary<string, float> energyOut = new Dictionary<string, float>();

	public Organism()
	{
	}
}