using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Bacteria: Organism
{
	public Cell[,] cellBody = new Cell[10,10];

	public Bacteria(Cell[,] bacteria)
	{
		cellBody = bacteria;
	}

	public void evolve()
	{
	}
}