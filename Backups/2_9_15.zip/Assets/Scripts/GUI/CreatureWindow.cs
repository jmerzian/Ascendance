using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Ascendance;
using GUIControl;

public static class CreatureWindow
{
	private static Planet planet;
	private static Biome biome;

	public static void WindowInformation(int ID)
	{
		planet = GUIDisplay.printedPlanet;
		biome = GUIDisplay.printedBiome;
		//use ID to switch what list is loaded
		switch(ID)
		{
			//sentient
		case 0:
			break;
			//animal
		case 1:
			break;
			//plant
		case 2:
			break;
			//bacterium
		case 3:
			break;
		}
		//allow the window to be resized
		GUI.DragWindow ();
	}
}