using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public static class GeneticEngineering
{
	//Set of bools to detect which animal group is being editted
	private static bool bacteriaEdit;
	private static bool plantEdit;
	private static bool animalEdit;

	private static string name = "OM NOM";

	/***************************************
	 * holder variables
	 * ************************************/
	//holder for the current scroll position
	private static Vector2 scrollPosition = new Vector2();

	//holder for the current state of the bacteria being created
	private static Cell[,] tempCells = new Cell[10,10];
	//the actively selected cell
	private static Cell activeCell = null;

	public static void windowDisplay(int ID)
	{
		//pause the game
		Control.Pause ();

		GUI.BeginGroup(new Rect(8,20,255,20));
		bacteriaEdit = GUI.Toggle (new Rect(0,0,64,20),bacteriaEdit,"Bacteria");
		plantEdit = GUI.Toggle (new Rect(80,0,64,20),plantEdit, "Plants");
		animalEdit = GUI.Toggle (new Rect(160,0,64,20),animalEdit, "Animals");
		GUI.EndGroup();

		//Display all information to engineer a creature
		if(bacteriaEdit)
		{
			bacteriaEngineering();
			plantEdit = false;
			animalEdit = false;
		}
		if(plantEdit)
		{
			plantEngineering();
			bacteriaEdit = false;
			animalEdit = false;
		}
		if(animalEdit)
		{
			animalEngineering();
			bacteriaEdit = false;
			plantEdit = false;
		}

		if(GUI.Button(new Rect(Screen.width-120,Screen.height-20,120,20),"Close"))
		{
			GUIMain.windowDisplay[4] = false;
		}
	}
	private static void bacteriaEngineering()
	{
		/*******
		 * Leftmost Collumn
		 * *****/
		//display all saved cells which can be added to the bacteria organism
		GUI.BeginGroup (new Rect(8,40,240,Screen.height-40));
		name = GUI.TextField (new Rect(0,0,240,20),name);
		scrollPosition = GUI.BeginScrollView (new Rect(0,40,240,Screen.height-80), scrollPosition, new Rect(0, 0, 240,CellEngineering.savedCells.Count*36));
		int i = 0;
		foreach(KeyValuePair<string,Cell> Cell in CellEngineering.savedCells)
		{
			GUI.DrawTexture(new Rect(0,30*i,30,30),Cell.Value.sprite, ScaleMode.ScaleToFit);
			if(GUI.Button(new Rect(40,30*i,200,24),Cell.Key)) activeCell = Cell.Value;
			i++;
		}
		GUI.EndScrollView ();
		if(GUI.Button(new Rect(0,Screen.height-60,120,20),"New Cell Type"))
		{
			//CLose this window and Open up cell engineering window
			GUIMain.windowDisplay[4] = false;
			GUIMain.windowDisplay[6] = true;
		}
		GUI.EndGroup ();

		/**************************
		 * Viewing Window
		 * ***********************/
		Vector2 viewWindow = new Vector2(Screen.height,Screen.height);

		if(Input.GetMouseButtonDown (0))
		{
			int xPos = Mathf.FloorToInt((Input.mousePosition.x-260)/(0.1f*viewWindow.x));
			int yPos = Mathf.FloorToInt((-Input.mousePosition.y+Screen.height-40)/(0.1f*viewWindow.y));
			if(xPos > -1 && xPos < 10 && yPos > -1 && yPos < 10)tempCells[xPos,yPos] = activeCell;
			Debug.Log(xPos + " " + yPos);
		}
		if(Input.GetMouseButtonDown(1))
		{
			int xPos = Mathf.FloorToInt((Input.mousePosition.x-260)/(0.1f*viewWindow.x));
			int yPos = Mathf.FloorToInt((-Input.mousePosition.y+Screen.height-40)/(0.1f*viewWindow.y));
			if(xPos > -1 && xPos < 10 && yPos > -1 && yPos < 10)tempCells[xPos,yPos] = null;
			Debug.Log(xPos + " " + yPos);
		}

		GUI.BeginGroup (new Rect(260,40,viewWindow.x,viewWindow.y));
		for(int x = 0; x < 10; x++)
		{
			for(int y = 0; y < 10; y++)
			{
				if(tempCells[x,y] != null)
				{
					GUI.DrawTexture(new Rect(x*0.1f*viewWindow.x,y*0.1f*viewWindow.y,0.1f*viewWindow.x,0.1f*viewWindow.y),tempCells[x,y].sprite);
				}
			}
		}
		GUI.EndGroup ();
		/*************************
		 * RightMost Column holds stats and information about specific bacteria
		 * **********************/
		GUI.BeginGroup (new Rect(Screen.width-220,40,240,Screen.height-40));
		GUI.Box (new Rect(0,0,210,Screen.height-60),"");
		GUI.EndGroup ();

		if(GUI.Button(new Rect(Screen.width-240,Screen.height-20,120,20),"Create"))
		{
		}
	}
	private static void plantEngineering()
	{
	}
	private static void animalEngineering()
	{
	}
}

