using UnityEngine;
using System.Collections.Generic;

public static class CellTextures
{
	public static Dictionary<string, Texture2D> textureList;
}