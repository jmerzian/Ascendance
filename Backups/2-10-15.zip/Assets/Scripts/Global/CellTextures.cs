using UnityEngine;
using System.Collections;
using System.Collections.Generic;

static class CellTextures
{
	public static Dictionary<string,Texture2D> textures = new Dictionary<string,Texture2D>();

	public static void initTextures()
	{
		foreach(string cellType in CellEngineering.cellName)
		{
			Texture2D newTexture = (Texture2D)Resources.Load("Textures/Cell/"+cellType);
			textures.Add(cellType,newTexture);
			if(newTexture!=null)Debug.Log("loaded " + cellType);
		}
		foreach(string resource in Control.gasses)
		{
			Texture2D newTexture = (Texture2D)Resources.Load("Textures/Cell/"+resource);
			textures.Add(resource,newTexture);
			if(newTexture!=null)Debug.Log("loaded " + resource);
		}
		foreach(string resource in Control.minerals)
		{
			Texture2D newTexture = (Texture2D)Resources.Load("Textures/Cell/"+resource);
			textures.Add(resource,newTexture);
			if(newTexture!=null)Debug.Log("loaded " + resource);
		}
		foreach(string resource in Control.organics)
		{
			Texture2D newTexture = (Texture2D)Resources.Load("Textures/Cell/"+resource);
			textures.Add(resource,newTexture);
			if(newTexture!=null)Debug.Log("loaded " + resource);
		}
		foreach(string resource in Control.energies)
		{
			Texture2D newTexture = (Texture2D)Resources.Load("Textures/Cell/"+resource);
			textures.Add(resource,newTexture);
			if(newTexture!=null)Debug.Log("loaded " + resource);
		}
	}
}