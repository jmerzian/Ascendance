using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Ascendance;

namespace GUIControl
{
	public static class GUIDisplay
	{
		//whether or not to display the biome or planet information
		public static bool printBiome;
		public static bool printPlanet;

		//which biome or planet to print
		public static Biome printedBiome;
		public static Planet printedPlanet;

		public static void PrintBiome(Biome selectedBiome, Planet selectedPlanet)
		{
			//siplay information about the currently selected biome
			if(selectedBiome != null)
			{
				printBiome = true;
				printedBiome = selectedBiome;
				printedPlanet = selectedPlanet;
			}
			else
			{
				printBiome = false;
			}
		}

		public static void PrintPlanet(Planet selectedPlanet)
		{
			//siplay information about the currently selected planet
			if(selectedPlanet != null)
			{
				printPlanet = true;
				printedPlanet = selectedPlanet;
			}
			else if(printBiome == true)
			{
				printPlanet = true;
			}
			else
			{
				printPlanet = false;
			}
		}
	}
	public static class GUIAction
	{
		public static void SelectBiome(Transform selectedBiome)
		{
			if(selectedBiome != null)
			{
				Planet selectedPlanet = selectedBiome.parent.GetComponent<Planet>();
				//If valid Biome is selected display information about that biome
				Dictionary<Transform,Biome> planetBiomes = selectedPlanet.GetPlanetBiomes();
				if(planetBiomes.ContainsKey(selectedBiome))
				{
					GUIDisplay.PrintBiome(planetBiomes[selectedBiome],selectedPlanet);
				}
				else
				{
					Debug.LogError("Uncategorized biome... get yo biomes together bro");
				}
			}
			else
			{
				GUIDisplay.PrintBiome(null,null);
			}
		}

		public static void SelectPlanet(Transform selectedPlanet)
		{
			if(selectedPlanet != null)
			{
				GUIDisplay.PrintPlanet (selectedPlanet.GetComponent<Planet>());
			}
			else
			{
				GUIDisplay.PrintPlanet(null);
			}
		}
	}
}