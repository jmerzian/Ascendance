using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Bacteria: Organism
{
	public Cell[,] cellBody = new Cell[10,10];

	public Bacteria()
	{
	}

	public Bacteria(Cell[,] bacteria)
	{
		cellBody = bacteria;
	}

	public void Simulate(BiomeResources mineral,PlanetResources gas, EnergyResources energies)
	{	
	}

	public void UpdateCell(int x, int y, Cell newCell)
	{
		Vector2[] directions = new Vector2[8]
		{new Vector2(1,1),
			new Vector2(1,0),
			new Vector2(0,1),
			new Vector2(-1,-1),
			new Vector2(0,-1),
			new Vector2(-1,0),
			new Vector2(1,-1),
			new Vector2(-1,1),
		};	
		//Previous Cell
		Cell previousCell;

		//Resoure Quantity to feed the given Cell
		float resourceQuantity;

		//Energy Quantity to feed the given Cell
		float energyQuantity;

		if(cellBody[x,y] != null) 
		{
			previousCell = new Cell (cellBody [x, y]);
		}
		else previousCell = new Cell();
		cellBody [x, y] = new Cell (newCell);

		foreach(KeyValuePair<string,float> resource in previousCell.resourceOut)
		{
			cellBody[x,y].resourceOut[resource.Key] = resource.Value;
		}

		//check all energies being used by this cell
		//TODO this could use some cleanup...
		foreach(KeyValuePair<string,float> energy in newCell.energyIn)
		{
			//check all resources in use
			foreach(KeyValuePair<string,float> resource in newCell.resourceIn)
			{
				foreach(Vector2 dir in directions)
				{
					if(x+(int)dir.x >= 0 && x+(int)dir.x < 10 && y+(int)dir.y >= 0 && y+(int)dir.y < 10)
					{
						/************************************************************************************
						 * Set The adjacent Cells to appropriate values for each different type of cell
						 * ****************************************************************************/
						//if the location doesn't contain a cell create a blank one
						if(cellBody[x+(int)dir.x,y+(int)dir.y] == null) 
							cellBody[x+(int)dir.x,y+(int)dir.y] = new Cell();
						/********************************************
						 * Producer
						 * ***************************************/
						if(newCell.type == "Producer" || previousCell.type == "Producer")
						{
							string outputResource = Recipes.recipes[energy.Key].getResult(resource.Key);

							//make sure that the recipe does in fact create something and that it isn't an energy...
							//TODO figure out a good way to handle energies...
							if(outputResource != null && !Control.energies.Contains(outputResource))
							{
								//add or subtract the surounding squares accordingly
								//if(cellBody[x+(int)dir.x,y+(int)dir.y].type == null)
								//{
									//set the empty cell to contain energy*input resource * efficiency of cell
									cellBody[x+(int)dir.x,y+(int)dir.y].resourceOut[outputResource] -= 
										previousCell.energyIn[energy.Key]*previousCell.resourceIn[resource.Key];
									cellBody[x+(int)dir.x,y+(int)dir.y].resourceOut[outputResource] += 
										energy.Value*resource.Value;
								//}
							}
						}
						/******************************************
						 * Transport
						 * ****************************************/
						if(previousCell.type == "Transport")
						{
							cellBody[x+(int)dir.x,y+(int)dir.y].resourceOut[resource.Key] -= 
								previousCell.resourceOut[resource.Key];
						}
						if(newCell.type == "Transport")
						{
							cellBody[x+(int)dir.x,y+(int)dir.y].resourceOut[resource.Key] += 
								cellBody[x,y].resourceOut[resource.Key];
						}

						/****************************************
						 * null
						 * ***************************************/
						//if a cell is bein removed re-calculate for what used to be in that location
						if(newCell.type == null)
						{
							//if it's the first run reset all values to what it was before the producer
							if(dir == directions[0]) cellBody[x,y].resourceOut[resource.Key] = previousCell.resourceOut[resource.Key];
							//if this cell used to be a producer zero it out
							if(previousCell.type != null)
							{	
								//if the nearby cell is a producer recalculate the values
								if(cellBody[x+(int)dir.x,y+(int)dir.y].type == "Producer")
								{
									string outputResource = Recipes.recipes[energy.Key].getResult(resource.Key);
									if(outputResource != null && !Control.energies.Contains(outputResource)) cellBody[x,y].resourceOut[outputResource] += 
										cellBody[x+(int)dir.x,y+(int)dir.y].energyIn[energy.Key]*cellBody[x+(int)dir.x,y+(int)dir.y].resourceIn[resource.Key];
								}
								if(cellBody[x+(int)dir.x,y+(int)dir.y].type == "Transport")
								{
									cellBody[x,y].resourceOut[resource.Key] += 
										cellBody[x+(int)dir.x,y+(int)dir.y].resourceOut[resource.Key];
								}
							}
						}
					}
				}
			}
		}
	}


	public void Render()
	{
	}

	public void Evolve()
	{
	}
}