using UnityEngine;
using System.Collections.Generic;

namespace Ascendance
{
	public class Biome
	{
		//basic information about biome
		public string name;
		public bool selected;
		public BiomeResources resources = new BiomeResources();

		//parent planet
		Planet parent;

		public Biome(string Name, Planet parentPlanet)
		{
			name = Name;
			parent = parentPlanet;

			foreach(string mineral in Control.minerals)
			{
				resources.mineralQuantities[mineral] = 10;
			}
		}
	}
}