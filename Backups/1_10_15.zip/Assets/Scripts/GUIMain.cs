using UnityEngine;
using System.Collections.Generic;
using GUIControl;
using Resources;
using Ascendance;

public class GUIMain : MonoBehaviour
{
	//textures for the end and in between of resource bars
	public Texture barBase;
	public Texture barBaseEnd;

	//Textures used for diplaying the solar system model 0:sun, 1:planet, 2:moon
	public List<Texture> modelTextures = new List<Texture> ();
	public Transform sun;
	
	private int ScreenWidth;
	private int ScreenHeight;
	
	// window controls
	private Rect[] informationWindows = new Rect[]{new Rect(),new Rect(),new Rect(),new Rect()};
	
	//which windows are open
	private bool[] windowDisplay = new bool[]{false,false,false,false,false};
	private string[] windowName = new string[]{"Sentients","Animals","Plants","Bacterium"};

	public void Start()
	{
		//get the current screen dimensions so that everything can be placed properly
		ScreenHeight = Screen.height;
		ScreenWidth = Screen.width;

		//Set the default size and position of the pop up windows
		for(int i = 0; i < informationWindows.Length; i++)
		{
			informationWindows[i] = new Rect(0,0,ScreenWidth-180,ScreenHeight-24);
		}

		SolarSystemDisplay.SetUp (modelTextures, sun);
	}

	public void OnGUI()
	{
		//Update the current screen dimensions so that everything can be placed properly
		ScreenHeight = Screen.height;
		ScreenWidth = Screen.width;
		
		/**********************************************
		* Resource and planet displays
		* **********************************************/
		//Display the universal resources Faith and Souls
		Color[] resourceColors = new Color[]{Color.yellow,Color.magenta};
		string[] resourceNames = new string[]{"Faith","Souls"};
		
		for(int i = 0; i < UniversalResources.universalQuantities.Count; i++)
		{
			ResourceBar(UniversalResources.universalQuantities[i], 100, new Rect(0,24*i+8,125,16),resourceColors[i], resourceNames[i]);
		}
		
		//if the planet is to be displayed display all of the planet information in a clear concise beautiful way
		if(GUIDisplay.printPlanet)
		{
			PlanetInformation(GUIDisplay.printedPlanet);
		}
		
		//if the biome is to be displayed display all of the biome information in a clear concise beautiful way
		if(GUIDisplay.printBiome)
		{
			
			BiomeInformation(GUIDisplay.printedBiome);
		}
		/**********************************************************
		 * Solar system display allowing changing of planet focus
		 * ********************************************************/
		SolarSystemDisplay.DisplaySystem(modelTextures);
		
		/**********************************************************
		* Buttons to open creatue info windows
		* ********************************************************/
		for(int i = 0; i < 4; i++)
		{
			windowDisplay[i] = GUI.Toggle (new Rect (ScreenWidth - 120, 248 + 50*i, 120, 40), windowDisplay[i], windowName[i]);
			if(windowDisplay[i])
			{
				informationWindows[i] = GUI.Window(i,informationWindows[i],InformationWindow,windowName[i]);
				for(int j = 0; j < 4; j++)
				{
					if(i != j) windowDisplay[j] = false;
				}
			}
		}

	/***********************************************************
	 * Genetic Engineering
	 * ********************************************************/
		windowDisplay[4] = GUI.Toggle (new Rect(ScreenWidth-120, ScreenHeight-120, 120,120),windowDisplay[4], "Genetic \n Engineering");
		if(windowDisplay[4])
		{
			//Open genetic engineering window and do something...
		}

	/***********************************************************
	 * General Useful Information
	 * *********************************************************/
		if (Control.paused) GUI.Label (new Rect (ScreenWidth / 2 - 120, 0, 240, 60), "PAUSED");
	}
	/*****************************************************************
	* Resource bar displays a recource in x number of blocks
	* ***********************************************************/
	
	private void ResourceBar(float resourceCurrent, float resourceMax, Rect position, Color color)
	{
		int i;
		
		//calculate number of sections to fit into required size
		int numOfSections = (int)Mathf.Ceil(position.width / 16);
		float numPerSection = resourceMax / numOfSections;
		int displayedSections = (int)Mathf.Ceil(resourceCurrent / numPerSection);
		
		GUI.color = color;
		
		for(i = 0; i < displayedSections; i++)
		{
			GUI.DrawTexture(new Rect(position.x + 16*i + 1, position.y, 16, 16),barBase);
		}
		GUI.DrawTexture(new Rect(position.x + 16*i + 1, position.y, 16, 16),barBaseEnd);
		
		GUI.color = Color.white;
	}
	
	private void ResourceBar(float resourceCurrent, float resourceMax, Rect position, Color color, string name)
	{
		ResourceBar (resourceCurrent, resourceMax, position, color);
		GUI.Label (new Rect(position.x,position.y-4,position.width,32), name + " : " + resourceCurrent);
	}
	
	/********************************************************************************
		 * General planet and biome information
		 * TODO print out resource quantities in resource blocks
		 * *****************************************************************************/
	private void PlanetInformation(Planet selectedPlanet)
	{
		if(selectedPlanet.resources.hasAtmosphere())
		{
			GUI.Box (new Rect(ScreenWidth-120,0,120,120),selectedPlanet.gameObject.name + "\n" +
			         "Pressure: " + selectedPlanet.resources.getPressure(selectedPlanet.Radius)+
			         "\nOxygen: " + selectedPlanet.resources.gasQuantities[0]+
			         "\nNitrogen: " + selectedPlanet.resources.gasQuantities[1]+
			         "\nMethane: " + selectedPlanet.resources.gasQuantities[2]+
			         "\nCarbon Dioxide: " + selectedPlanet.resources.gasQuantities[3]+
			         "\nHydrogen: " + selectedPlanet.resources.gasQuantities[4]);
		}
		else GUI.Box (new Rect(ScreenWidth-120,0,120,120),selectedPlanet.gameObject.name + "\nHas no atmosphere.");
	}
	
	private void BiomeInformation(Biome selectedBiome)
	{
		//water, ammonia, calcium, Iron, Sulfur,Uranium
		GUI.Box (new Rect(ScreenWidth-120,120,120,120), selectedBiome.name + "\n" +
		         "Water: " + selectedBiome.resources.mineralQuantities[0]+
		         "\nAmmonia: " + selectedBiome.resources.mineralQuantities[1]+
		         "\nCalcium: " + selectedBiome.resources.mineralQuantities[2]+
		         "\nIron: " + selectedBiome.resources.mineralQuantities[3]+
		         "\nSulfur: " + selectedBiome.resources.mineralQuantities[4]+
		         "\nUranium: " + selectedBiome.resources.mineralQuantities[5]);
	}
	
	/********************************************************************************
		 * Open windows to display more information about various plants and animals
		 * ****************************************************************************/
	public void InformationWindow(int ID)
	{
		GUI.DragWindow ();
		CreatureWindow.WindowInformation (ID);
	}
}