using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using Ascendance;
using GUIControl;

public static class CreatureWindow
{
	private static Planet planet;
	private static Biome biome;
	private static List<Creature> informationList = new List<Creature>();

	public static void WindowInformation(int ID)
	{
		planet = GUIDisplay.printedPlanet;
		biome = GUIDisplay.printedBiome;
		//use ID to switch what list is loaded
		switch(ID)
		{
			//sentient
		case 0:
			break;
			//animal
		case 1:
			break;
			//plant
		case 2:
			break;
			//bacterium
		case 3:
			if(GUIDisplay.printBiome)
			{
				Dictionary<string,BacteriaSpecies> biomeBacteria = planet.GetBiomeBacteria(biome);
				int i = 0;
				if(biomeBacteria != null)
				{
					foreach(KeyValuePair<string,BacteriaSpecies> bacteria in biomeBacteria)
					{
						GUI.Box(new Rect(0,40*i + 20,240,40),bacteria.Key + "\n" + bacteria.Value.quantity);
						i++;
					}
				}
			}
			else if(GUIDisplay.printPlanet)
		    {
				Dictionary<string,BacteriaSpecies> planetBacteria = planet.GetPlanetBacteria();
				int i = 0;
				foreach(KeyValuePair<string,BacteriaSpecies> bacteria in planetBacteria)
				{
					GUI.Box(new Rect(0,40*i + 20,240,40),bacteria.Key+ "\n" + bacteria.Value.quantity);
					i++;
				}
			}
			break;
		}
	}
}