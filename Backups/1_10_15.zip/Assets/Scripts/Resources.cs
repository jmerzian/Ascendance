using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace Resources
{
	//List of public resources used by the game
	//Faith, Souls
	public enum Universal{FAITH,SOULS};

	//list of gasses that can be present in the atmosphere
	//Oxygen, nitrogen, methane, carbondioxide,hydrogen
	public enum Gasses{O2,N2,CH4,CO2,H2};

	//list of minerals that can be present in the soil
	//water, ammonia, calcium, Iron, Sulfur, Uranium
	public enum Minerals{H2O,NH4,CA2,FE2,SO4,U};

	[System.Serializable]
	public static class UniversalResources
	{
		public static List<float> universalQuantities = new List<float>{100,100};
	}

	[System.Serializable]
	public class BiomeResources
	{
		//for inspector purposes only... doesn't actually do anything...
		public string note = "H2O,NH4,CA2,FE2,SO4,U";
		public List<float> mineralQuantities = new List<float>{0,0,0,0,0,0};

		//Minerals need a weight and a quantity
		//water, ammonia, calcium, Iron, Sulfur,Uranium
		private List<float[]> minerals = new List<float[]>(){
			new float[]{18,0},
			new float[]{18,0},
			new float[]{80,0},
			new float[]{112,0},
			new float[]{92,0},
			new float[]{235,0}};
	}

	[System.Serializable]
	public class PlanetResources
	{
		//for inspector purposes only... doesn't actually do anything...
		public string note = "O2,N2,CH4,CO2,H2";
		public List<float> gasQuantities = new List<float>{0,0,0,0,0};

		//Gasses need a weight and a quantity
		//Oxygen, nitrogen, methane, carbon-dioxide, hydrogen
		private List<float[]> gasses = new List<float[]>(){
			new float[]{32,0},
			new float[]{28,0},
			new float[]{16,0},
			new float[]{44,0},
			new float[]{2,0}};

		//calculated from other variables
		private bool atmosphere;
		private float gasWeight;
		private float pressure;

		public void UpdateResources()
		{
			int numOfGasses = gasses.Count;
			int i = 0;
			for(;i < gasQuantities.Count ; i++)
			{
				if(i <= numOfGasses) gasses[i][1] = gasQuantities[i];
			}
			for(;i < numOfGasses; i++)
			{
				gasses[i][1] = 0;
			}
		}

		//if anything in the gasses has
		public bool hasAtmosphere()
		{
			getPressure (1);

			if(gasWeight > 0) atmosphere = true;
			else atmosphere = false;

			return atmosphere;
		}

		public float getPressure(float radius)
		{
			UpdateResources ();
			gasWeight = 0;
			foreach(float[] gas in gasses)
			{
				gasWeight += gas[0]*gas[1];
			}
			pressure = gasWeight / (200 * 3.1415f * radius);
			return pressure;
		}
	}
}