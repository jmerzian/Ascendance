using UnityEngine;
using System;
using System.Collections.Generic;

public class Bacteria
{
	public string name;
	//if the bacteria is parasitic or not
	public bool parasitic;
	//size of the bacteria, relates to nutrients needed
	public float size;
	//Range of temperatures the bacteria can survive in
	public float[] tempRange = new float[]{0,1};

	/*******************************************************8
	 * Mediums the bacteria is capable of moving through
	 * *********************************************************/
	public string[] movementTypes = new string[]{"water","air","organism","soil"};
	public Dictionary<string,bool> movementCapable = new Dictionary<string,bool>();
	public Dictionary<string,float> movementSpeed = new Dictionary<string,float>();

	/****************************************************************
	 * Sources of nutrients available to bacteria
	 * ***************************************************************/
	public string[] nutrientTypes = new string[]{"mineral","animal","air"};
	public Dictionary<string,bool> nutrientCapable = new Dictionary<string,bool>();
	public Dictionary<string,float> nutrientEfficiency = new Dictionary<string,float>();

	/***********************************************************************
	 * Sources of energy available to bacteria
	 * *********************************************************************/
	public string[] energyTypes = new string[]{"heat","light","radiation"};
	public Dictionary<string,bool> energyCapable = new Dictionary<string,bool>();
	public Dictionary<string,float> energyEfficiency = new Dictionary<string,float>();

	public Bacteria()
	{
		foreach(string movement in movementTypes)
		{
			movementCapable.Add(movement,false);
			movementSpeed.Add(movement,0);
		}
		foreach(string nutrient in nutrientTypes)
		{
			nutrientCapable.Add(nutrient,false);
			nutrientEfficiency.Add(nutrient,0);
		}
		foreach(string energy in energyTypes)
		{
			energyCapable.Add(energy,false);
			energyEfficiency.Add(energy,0);
		}
	}

	public Bacteria (string newName, float[] movement, float[] nutrient, float[] energy) : this()
	{
		name = newName;

		//modify each value of the dictionary
		for(int i = 0; i < movement.Length; i++)
		{
			movementSpeed[movementTypes[i]] = movement[i];
			if(movement[i]>0) movementCapable[movementTypes[i]] = true;
		}

		//modify each value of the dictionary
		for(int i = 0; i < nutrient.Length; i++)
		{
			nutrientEfficiency[nutrientTypes[i]] = nutrient[i];
			if(nutrient[i]>0) nutrientCapable[nutrientTypes[i]] = true;
		}

		//modify each value of the dictionary
		for(int i = 0; i < energy.Length; i++)
		{
			energyEfficiency[energyTypes[i]] = energy[i];
			if(energy[i]>0) energyCapable[energyTypes[i]] = true;
		}
	}
}