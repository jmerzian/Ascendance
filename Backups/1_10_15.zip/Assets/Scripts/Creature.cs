using UnityEngine;
using System.Collections;

public class Creature : MonoBehaviour
{

}

public class BacteriaSpecies : Bacteria
{
	public int quantity;

	public BacteriaSpecies(Bacteria baseBacteria, int speciesQuantity)
	{
		quantity = speciesQuantity;
	}
}