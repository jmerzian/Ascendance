﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Main : MonoBehaviour 
{
	//Useful objects
	public Transform Sun;

	//Gameflow Variables
	public float turnTime;

	//Loading variables
	public Texture2D loadingMenu;
	bool go;
	bool loaded;
	private int loadingProgress;

	private string[] loadingMessage = new string[]
	{
		"Imaging Microbes",
		"Devising Devious Concoctions",
		"Gathering critters from home",
		"Organizing Otherworldly Blueprints",
		"Perusing Geological Blueprints",
		"Architecturalizing landscapes"
	};

	void Start ()
	{
		loaded = false;
		go = false;
		StartCoroutine(LoadScene ());
	}

	void OnGUI()
	{
		//Set the skin
		GUI.skin = GUIMain.editorSkin;
		if(!go)
		{
			GUI.DrawTexture(new Rect(0,0,Screen.width,Screen.height),loadingMenu);
			if(loaded)
			{
				if(GUI.Button(new Rect(Screen.width/2-120,Screen.height-240,240,40),"GO"))
				{
					go = true;
					//Show GE window
					//GUIMain.windowDisplay [4] = true;
				}
			}
			else
			{
				GUI.Label(new Rect(Screen.width/2-240,Screen.height-240,480,40),loadingMessage[loadingProgress]);
			}
		}
	}

	private IEnumerator LoadScene()
	{
		/*****************************
		 * Load things
		 * ******************************/
		//TODO delete this... it's solely for testing purposes
		//load cell textures
		CellTextures.initTextures();
		loadingProgress = 0;
		yield return null;
		//initialize the windows
		Recipes.initRecipes();
		loadingProgress = 1;
		yield return null;
		//load default cells
		ExampleCells.loadCells();
		for(int z = 0; z < ExampleCells.testCellNames.Length; z++) CellEngineering.savedCells.Add(ExampleCells.testCellNames[z],ExampleCells.testCells[z]);
		loadingProgress = 2;
		yield return null;
		//initialize the Bacteria GE grid
		//GeneticEngineering.ClearGrid ();
		loadingProgress = 3;
		yield return null;
		BiomeTypes.init ();
		loadingProgress = 4;
		yield return null;
		//initPlanets (Sun);
		loadingProgress = 5;
		loaded = true;
	}

	private void initPlanets(Transform parent)
	{
		for(int i = 0; i < parent.childCount; i++)
		{
			if(parent.GetChild(i).childCount > 0)
			{
				initPlanets(parent.GetChild(i));
			}
			if(parent.GetChild(i).tag == "Planet")
			{
				parent.GetChild(i).GetComponent<Planet>().Init();
			}
		}
	}

	//TODO evolve the creature here
	private IEnumerator evolveCreatures()
	{
		//Set the flag that signals that creatures are evolving
		Control.evolving = true;
		yield return null;
		//Once completed free the game to resume
		Control.evolving = false;
		yield return null;
	}

	//Control the game flow from here
	/*************************************
	 * Current Flow:
	 * run for turnTime secs
	 * pause the game
	 * evolve species
	 * show even window
	 * *********************************/
	void Update () 
	{	
		if (GUIMain.windowDisplay [6])
						StartCoroutine(CellEngineering.drawCell ());
	}
}
