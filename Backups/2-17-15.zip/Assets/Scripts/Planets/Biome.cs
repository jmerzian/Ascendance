using UnityEngine;
using System.Collections.Generic;

public class Biome
{
	//basic information about biome
	public string type;
	public bool selected;
	public BiomeResources resources = new BiomeResources();
	public LifeResources life = new LifeResources();

	//parent planet
	//Planet parent;

	public Biome(string newType)
	{
		type = newType;

		foreach(string mineral in Control.minerals)
		{
			Debug.Log("placing " + 10 + "mineral");
			resources.mineralQuantities[mineral] = 10;
		}
	}

	public Biome(string newType,BiomeResources resources)
	{
		type = newType;

		resources = new BiomeResources (resources);
	}

	public Biome(Biome copy)
	{
		type = copy.type;

		selected = copy.selected;

		resources = new BiomeResources (copy.resources);
		life = new LifeResources (copy.life);
	}
}