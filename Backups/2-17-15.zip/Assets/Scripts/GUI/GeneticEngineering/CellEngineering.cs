using UnityEngine;
using System.Collections;
using System.Collections.Generic;
//TODO finish up the interface for creating the different kinds of cells
public static partial class CellEngineering
{
	/*************************
	 * Holder Variables
	 * ***************************/
	//holder for all saved cells
	public static Dictionary<string,Cell> savedCells = new Dictionary<string,Cell>();
	//Temporary holder for the finsihed cell properties
	private static string name = "New Cell";
	private static Cell tempCell = new Cell ();

	//Dictates what type of cell is being created
	public static bool[] cellDisplay = new bool[]{false,false,false,false,false,false,false};
	public static string[] cellName = new string[]{"Producer","Transport","Nueral","Utility"};

	private static bool rendered = false;

	//GUI variables
	private static Vector2[] scroll = new Vector2[8];
	private static int outputTextRows;
   
	public static void CreateCell(int ID)
	{
		//Change the GUI skin to the editor
		GUI.skin = GUIMain.editorSkin;
		//Pause the game and adjust the render to happen once per second
		Control.Pause ();

		
		/***************************
		 * Clear all of the outpus to make sure an accurate value is output
		 * ***************************/
		foreach(string energy in Control.energies)
		{
			tempCell.energyOut[energy] = 0;
		}
		foreach(string resource in Control.minerals)
		{
			tempCell.resourceOut[resource] = 0;
		}
		foreach(string resource in Control.gasses)
		{
			tempCell.resourceOut[resource] = 0;
		}
		foreach(string resource in Control.organics)
		{
			tempCell.resourceOut[resource] = 0;
		}
		//Because life is wierd...
		tempCell.minimumToLive = 0;
		tempCell.energyOut ["Life"] = 1;
	
		/**************************************
		 * Top Row selects what type of cell is being created
		 * ********************************************/
		GUI.BeginGroup(new Rect(10,10,480,20));
		for(int i = 0; i < cellName.Length; i++)
		{
			cellDisplay[i] = GUI.Toggle (new Rect(120*i,0,120,30),cellDisplay[i],cellName[i]);
			if(cellDisplay[i])
			{
				tempCell.type = cellName[i];
				for(int j = 0; j < cellName.Length; j++)
				{
					if(i != j) cellDisplay[j] = false;
				}
			}
		}
		GUI.EndGroup();
		/*************************************************
		 * Left Collumn determines inputs
		 * Right collumn shows what the byproducts are, nutrients needed etc.
		 *
		 * //If producer show what is being produced
		 * //If transporter show what is being transported
		 * //If structural.. TODO something
		 * //If other... TODO something
		 * ************************************************/
		if(cellDisplay[0]) ProducerDisplay();
		else if(cellDisplay[1]) TransportDisplay();
		else if(cellDisplay[2]) NueralDisplay();
		/******************************************************************
		 * Center contains viewport for what the finished cell looks like and maybe some other things at the bottom....
		 * ***************************************************************/
		GUI.BeginGroup (new Rect(Screen.width/2 - 160,40,320,320));
		GUI.DrawTexture (new Rect(0,0,320,320),tempCell.sprite);
		GUI.EndGroup ();
	}
}