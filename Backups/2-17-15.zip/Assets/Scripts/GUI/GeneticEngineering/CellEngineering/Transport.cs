using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public static partial class CellEngineering
{
	private static float efficiency;

	private static void TransportDisplay()
	{
		/***************************************************************
		 * Left Collumn
		 * *************************************************************/
		GUI.BeginGroup (new Rect (20, 40, 300, Screen.height));
		//name of cell
		name = GUI.TextField(new Rect(0,0,300,20),name);
		//height of section
		float sectionHeight = (Screen.height-240) / 3;

		GUI.Label(new Rect(0,40,80,40),"Efficiency");
		efficiency = GUI.HorizontalSlider(new Rect(80,40,160,40),efficiency,0,1);

		GUI.Label (new Rect (0,80,240,24), "Organic Materials Used");
		scroll[2] = GUI.BeginScrollView (new Rect(0,104,260,sectionHeight), scroll[2], new Rect(0, 0, 240,Control.organics.Count*40));
		int i = 0;
		foreach(string organic in Control.organics)
		{
			GUI.Label(new Rect(0,40*i,80,40),Control.organics[i]);
			tempCell.resourceIn[organic] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),tempCell.resourceIn[organic],0,1);
			i++;
		}
		GUI.EndScrollView();
		
		GUI.Label (new Rect (0,120+sectionHeight,240,24), "Minerals Used");
		scroll[1] = GUI.BeginScrollView (new Rect(0,144+sectionHeight,260,sectionHeight), scroll[1], new Rect(0, 0, 240,Control.minerals.Count*40));
		i = 0;
		foreach(string mineral in Control.minerals)
		{
			GUI.Label(new Rect(0,40*i,80,40),Control.minerals[i]);
			tempCell.resourceIn[mineral] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),tempCell.resourceIn[mineral],0,1);
			i++;
		}
		GUI.EndScrollView ();
		
		GUI.Label (new Rect (0,160+2*sectionHeight,240,24), "Gasses Used");
		scroll[0] = GUI.BeginScrollView (new Rect(0,184+ 2*sectionHeight,260,sectionHeight), scroll[0], new Rect(0, 0, 240,Control.gasses.Count*40));
		i = 0;
		foreach(string gas in Control.gasses)
		{
			GUI.Label(new Rect(0,40*i,80,40),Control.gasses[i]);
			tempCell.resourceIn[gas] = GUI.HorizontalSlider(new Rect(80,40*i,160,40),tempCell.resourceIn[gas],0,1);
			i++;
		}
		GUI.EndScrollView ();

		GUI.EndGroup ();

		/*************************************************************
		 * Right Collumn
		 * ********************************************************/
		GUI.BeginGroup (new Rect(Screen.width-240,20,240,Screen.height));
		GUI.Label(new Rect(0,0,240,40),"Resources Stored");
		scroll[4] = GUI.BeginScrollView (new Rect(0,40,240,Screen.height-360), scroll[4], new Rect(0, 0, 220,outputTextRows*20));
		i = 0;
		foreach(KeyValuePair<string,float> resource in tempCell.resourceIn)
		{
			if(resource.Value > 0)
			{
				GUI.Label(new Rect(0,20*i,240,20),(efficiency*90*resource.Value).ToString("F2") + "% of " + resource.Key);
				i++;
				//minimum to live is calculated by size*efficieny of transport*efficiency of material
				tempCell.minimumToLive += efficiency*resource.Value;
				tempCell.resourceOut[resource.Key] = efficiency*0.9f*resource.Value;
				i++;
			}
		}
		outputTextRows = i;
		GUI.EndScrollView();

		if(GUI.Button(new Rect(0,Screen.height-60,100,30),"Save Cell"))
		{
			//Run checks to make sure that it is a valid Cell
			if(ValidTransport())
			{
				tempCell.name = name;
				savedCells.Add(name,new Cell(tempCell));
				tempCell = new Cell();
				GUIMain.windowDisplay[6] = false;
			}
		}
		if(GUI.Button(new Rect(100,Screen.height-60,100,30),"Close"))
		{
			GUIMain.windowDisplay[6] = false;
		}

		GUI.EndGroup ();
	}
	
	/********************************************
	 * Check to see if the cell is valid
	 * *************************************/
	private static bool ValidTransport()
	{
		if (savedCells.ContainsKey (name))return false;
		return true;
	}
}
