using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public static partial class GeneticEngineering
{
	//Set of bools to detect which animal group is being editted
	private static bool[] editing = new bool[]{false,false,false};
	private static string[] editName = new string[]{"Bacteria","Plants","Animals"};

	private static string name = "OM NOM";

	/***************************************
	 * holder variables
	 * ************************************/
	//holder for the current scroll position
	private static Vector2[] scroll = new Vector2[10];
	private static int[] outputTextRows = new int[10];

	/*****************************************
	 * Ideal environments used for simulation
	 * ***************************************/
	private static PlanetResources idealGasses = new PlanetResources();
	private static BiomeResources idealMinerals = new BiomeResources();
	private static EnergyResources idealEnergies = new EnergyResources();

	public static void windowDisplay(int ID)
	{
		//pause the game
		Control.Pause ();

		GUI.BeginGroup(new Rect(8,20,480,20));
		for (int i = 0; i < editName.Length; i++)
		{
			editing[i] = GUI.Toggle (new Rect(120*i,0,120,20),editing[i],editName[i]);
			if(editing[i])
			{
				//do something
				for(int j = 0; j < editName.Length; j++)
				{
					if(i != j) editing[j] = false;
				}
			}
		}
		GUI.EndGroup();

		if(editing[0]) bacteriaEngineering();
		if(editing[1]) plantEngineering();
		if(editing[2]) animalEngineering();

		if(GUI.Button(new Rect(Screen.width-160,Screen.height-30,160,30),"Close"))
		{
			GUIMain.windowDisplay[4] = false;
		}
	}
	private static void plantEngineering()
	{
	}
	private static void animalEngineering()
	{
	}
}

